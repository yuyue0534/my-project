import Database from 'better-sqlite3'
import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const dataDir = process.env.DATA_DIR || path.join(__dirname, '..', 'data')
fs.mkdirSync(dataDir, { recursive: true })

export const db = new Database(path.join(dataDir, 'knowbase.db'))
db.pragma('journal_mode = WAL')
db.pragma('foreign_keys = ON')

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);

-- 页面树：parent_id 表示父页面；content 为块数组的 JSON；plain_text 为抽取出的纯文本（用于搜索）
CREATE TABLE IF NOT EXISTS pages (
  id         TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  parent_id  TEXT REFERENCES pages(id) ON DELETE CASCADE,
  title      TEXT NOT NULL DEFAULT '',
  icon       TEXT NOT NULL DEFAULT '',
  content    TEXT NOT NULL DEFAULT '[]',
  plain_text TEXT NOT NULL DEFAULT '',
  position   REAL NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pages_user_parent ON pages(user_id, parent_id, position);
`)

// 全文搜索：FTS5 + trigram 分词器（对中文、英文都能做子串匹配，不需要额外分词库）
// 需要 SQLite >= 3.34；不可用时自动降级为 LIKE 查询
export let ftsEnabled = false
try {
  db.exec(`CREATE VIRTUAL TABLE IF NOT EXISTS pages_fts USING fts5(
    page_id UNINDEXED, title, body, tokenize = 'trigram'
  )`)
  ftsEnabled = true
} catch (e) {
  console.warn('[search] FTS5 trigram 不可用，已降级为 LIKE 搜索：', e.message)
}

export function reindexPage(pageId, title, plainText) {
  if (!ftsEnabled) return
  db.prepare('DELETE FROM pages_fts WHERE page_id = ?').run(pageId)
  db.prepare('INSERT INTO pages_fts (page_id, title, body) VALUES (?, ?, ?)').run(pageId, title, plainText)
}

export function removeFromIndex(pageId) {
  if (!ftsEnabled) return
  db.prepare('DELETE FROM pages_fts WHERE page_id = ?').run(pageId)
}
