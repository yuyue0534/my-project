import { Router } from 'express'
import { db } from '../db.js'
import { hashPassword, verifyPassword, createSession, requireAuth } from '../auth.js'
import { createWelcomePages } from '../welcome.js'

const router = Router()
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

router.post('/register', (req, res) => {
  const { email = '', password = '', name = '' } = req.body || {}
  const mail = String(email).trim().toLowerCase()
  if (!EMAIL_RE.test(mail)) return res.status(400).json({ error: '邮箱格式不正确' })
  if (String(password).length < 6) return res.status(400).json({ error: '密码至少 6 位' })
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(mail)) {
    return res.status(409).json({ error: '该邮箱已注册' })
  }
  const displayName = String(name).trim().slice(0, 50) || mail.split('@')[0]

  const userId = db.transaction(() => {
    const info = db
      .prepare('INSERT INTO users (email, name, password_hash, created_at) VALUES (?, ?, ?, ?)')
      .run(mail, displayName, hashPassword(String(password)), Date.now())
    createWelcomePages(info.lastInsertRowid)
    return Number(info.lastInsertRowid)
  })()

  const token = createSession(userId)
  res.json({ token, user: { id: userId, email: mail, name: displayName } })
})

router.post('/login', (req, res) => {
  const { email = '', password = '' } = req.body || {}
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).trim().toLowerCase())
  if (!user || !verifyPassword(String(password), user.password_hash)) {
    return res.status(401).json({ error: '邮箱或密码错误' })
  }
  const token = createSession(user.id)
  res.json({ token, user: { id: user.id, email: user.email, name: user.name } })
})

router.post('/logout', requireAuth, (req, res) => {
  db.prepare('DELETE FROM sessions WHERE token = ?').run(req.token)
  res.json({ ok: true })
})

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: req.user })
})

export default router
