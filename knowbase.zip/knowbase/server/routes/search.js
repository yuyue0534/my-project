import { Router } from 'express'
import { db, ftsEnabled } from '../db.js'
import { requireAuth } from '../auth.js'
import { makeSnippet } from '../util.js'

const router = Router()
router.use(requireAuth)

const escapeLike = (s) => s.replace(/[\\%_]/g, (c) => '\\' + c)
const charLen = (s) => [...s].length

function searchFts(userId, terms) {
  // trigram 分词要求每个词至少 3 个字符；多个词之间为 AND
  const match = terms.map((t) => `"${t.replace(/"/g, '""')}"`).join(' AND ')
  return db
    .prepare(
      `SELECT p.id, p.title, p.icon, p.plain_text, bm25(pages_fts, 0.0, 5.0, 1.0) AS score
       FROM pages_fts JOIN pages p ON p.id = pages_fts.page_id
       WHERE pages_fts MATCH ? AND p.user_id = ?
       ORDER BY score LIMIT 30`
    )
    .all(match, userId)
}

function searchLike(userId, terms) {
  const cond = terms.map(() => `(p.title LIKE ? ESCAPE '\\' OR p.plain_text LIKE ? ESCAPE '\\')`).join(' AND ')
  const params = terms.flatMap((t) => [`%${escapeLike(t)}%`, `%${escapeLike(t)}%`])
  return db
    .prepare(
      `SELECT p.id, p.title, p.icon, p.plain_text FROM pages p
       WHERE p.user_id = ? AND ${cond}
       ORDER BY (p.title LIKE ? ESCAPE '\\') DESC, p.updated_at DESC LIMIT 30`
    )
    .all(userId, ...params, `%${escapeLike(terms[0])}%`)
}

router.get('/', (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 100)
  const terms = q.split(/\s+/).filter(Boolean).slice(0, 6)
  if (terms.length === 0) return res.json({ results: [], engine: 'none' })

  let rows
  let engine = 'like'
  if (ftsEnabled && terms.every((t) => charLen(t) >= 3)) {
    try {
      rows = searchFts(req.user.id, terms)
      engine = 'fts5'
    } catch (e) {
      console.warn('[search] FTS 查询失败，回退 LIKE：', e.message)
    }
  }
  if (!rows) rows = searchLike(req.user.id, terms)

  const results = rows.map((r) => ({
    id: r.id,
    title: r.title,
    icon: r.icon,
    snippet: makeSnippet(r.plain_text, terms)
  }))
  res.json({ results, engine })
})

export default router
