import { Router } from 'express'
import { db, reindexPage, removeFromIndex } from '../db.js'
import { requireAuth } from '../auth.js'
import { sanitizeBlocks, extractText, newParagraph, uid } from '../util.js'

const router = Router()
router.use(requireAuth)

const getOwned = (id, userId) =>
  id ? db.prepare('SELECT * FROM pages WHERE id = ? AND user_id = ?').get(id, userId) : undefined

/** candidateId 是否位于 ancestorId 的子树内（含自身） */
function isInSubtree(candidateId, ancestorId) {
  let cur = candidateId
  for (let i = 0; cur && i < 1000; i++) {
    if (cur === ancestorId) return true
    cur = db.prepare('SELECT parent_id FROM pages WHERE id = ?').get(cur)?.parent_id
  }
  return false
}

// 页面树（不含正文，轻量）
router.get('/', (req, res) => {
  const pages = db
    .prepare(
      `SELECT id, parent_id, title, icon, position, created_at, updated_at
       FROM pages WHERE user_id = ? ORDER BY position, created_at`
    )
    .all(req.user.id)
  res.json({ pages })
})

// 新建页面
router.post('/', (req, res) => {
  const { parent_id = null, title = '', icon = '' } = req.body || {}
  if (parent_id && !getOwned(parent_id, req.user.id)) {
    return res.status(400).json({ error: '父页面不存在' })
  }
  const position = db
    .prepare('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM pages WHERE user_id = ? AND parent_id IS ?')
    .get(req.user.id, parent_id || null).p
  const now = Date.now()
  const id = uid()
  const content = [newParagraph()]
  db.prepare(
    `INSERT INTO pages (id, user_id, parent_id, title, icon, content, plain_text, position, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, '', ?, ?, ?)`
  ).run(id, req.user.id, parent_id || null, String(title).slice(0, 300), String(icon).slice(0, 8), JSON.stringify(content), position, now, now)
  reindexPage(id, String(title), '')
  res.status(201).json({
    page: { id, parent_id: parent_id || null, title: String(title), icon: String(icon), position, created_at: now, updated_at: now }
  })
})

// 读取单个页面（含正文）
router.get('/:id', (req, res) => {
  const page = getOwned(req.params.id, req.user.id)
  if (!page) return res.status(404).json({ error: '页面不存在' })
  const { plain_text, user_id, ...rest } = page
  res.json({ page: { ...rest, content: JSON.parse(page.content) } })
})

// 更新标题 / 图标 / 正文（任意子集）
router.put('/:id', (req, res) => {
  const page = getOwned(req.params.id, req.user.id)
  if (!page) return res.status(404).json({ error: '页面不存在' })
  const { title, icon, content } = req.body || {}

  const newTitle = typeof title === 'string' ? title.slice(0, 300) : page.title
  const newIcon = typeof icon === 'string' ? [...icon].slice(0, 4).join('') : page.icon
  let contentJson = page.content
  let plain = page.plain_text
  if (content !== undefined) {
    const blocks = sanitizeBlocks(content)
    if (!blocks) return res.status(400).json({ error: '正文格式不正确' })
    contentJson = JSON.stringify(blocks)
    plain = extractText(blocks)
  }
  const updatedAt = Date.now()
  db.transaction(() => {
    db.prepare('UPDATE pages SET title = ?, icon = ?, content = ?, plain_text = ?, updated_at = ? WHERE id = ?').run(
      newTitle, newIcon, contentJson, plain, updatedAt, page.id
    )
    reindexPage(page.id, newTitle, plain)
  })()
  res.json({ ok: true, updated_at: updatedAt })
})

// 移动页面：position = before | after | inside（相对 target_id），或 root（移到顶层末尾）
router.patch('/:id/move', (req, res) => {
  const page = getOwned(req.params.id, req.user.id)
  if (!page) return res.status(404).json({ error: '页面不存在' })
  const { target_id = null, position } = req.body || {}
  if (!['before', 'after', 'inside', 'root'].includes(position)) {
    return res.status(400).json({ error: 'position 不合法' })
  }

  let target = null
  let parentId = null
  if (position !== 'root') {
    target = getOwned(target_id, req.user.id)
    if (!target) return res.status(404).json({ error: '目标页面不存在' })
    if (isInSubtree(target.id, page.id)) return res.status(400).json({ error: '不能把页面移动到它自己或它的子页面中' })
    parentId = position === 'inside' ? target.id : target.parent_id
  }

  db.transaction(() => {
    const siblings = db
      .prepare('SELECT id FROM pages WHERE user_id = ? AND parent_id IS ? AND id <> ? ORDER BY position, created_at')
      .all(req.user.id, parentId, page.id)
      .map((r) => r.id)
    let index = siblings.length
    if (position === 'before' || position === 'after') {
      index = siblings.indexOf(target.id) + (position === 'after' ? 1 : 0)
    }
    siblings.splice(index, 0, page.id)
    db.prepare('UPDATE pages SET parent_id = ? WHERE id = ?').run(parentId, page.id)
    const upd = db.prepare('UPDATE pages SET position = ? WHERE id = ?')
    siblings.forEach((sid, i) => upd.run(i, sid))
  })()
  res.json({ ok: true })
})

// 删除页面（连同所有子页面）
router.delete('/:id', (req, res) => {
  const page = getOwned(req.params.id, req.user.id)
  if (!page) return res.status(404).json({ error: '页面不存在' })
  const ids = db
    .prepare(
      `WITH RECURSIVE sub(id) AS (
         SELECT id FROM pages WHERE id = ?
         UNION ALL
         SELECT p.id FROM pages p JOIN sub s ON p.parent_id = s.id
       ) SELECT id FROM sub`
    )
    .all(page.id)
    .map((r) => r.id)
  db.transaction(() => {
    ids.forEach(removeFromIndex)
    db.prepare('DELETE FROM pages WHERE id = ?').run(page.id) // 子页面由外键级联删除
  })()
  res.json({ ok: true, deleted: ids })
})

export default router
