import { db, reindexPage } from './db.js'
import { uid, extractText } from './util.js'

const b = (type, text = '', extra = {}) => ({ id: uid(), type, text, ...extra })

/** 新用户注册后自动创建的示例页面 */
export function createWelcomePages(userId) {
  const now = Date.now()
  const insert = db.prepare(
    `INSERT INTO pages (id, user_id, parent_id, title, icon, content, plain_text, position, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
  const make = (parentId, title, icon, blocks, position) => {
    const id = uid()
    const text = extractText(blocks)
    insert.run(id, userId, parentId, title, icon, JSON.stringify(blocks), text, position, now, now)
    reindexPage(id, title, text)
    return id
  }

  const rootId = make(
    null,
    '欢迎使用 Knowbase',
    '👋',
    [
      b('paragraph', '这是一个类 Notion 的知识库骨架。下面是你可以马上尝试的事情：'),
      b('h2', '编辑'),
      b('todo', '在空行输入 / 唤起命令菜单，选择块类型', { checked: false }),
      b('todo', '输入 "# " 、"- "、"1. "、"[] "、"> " 试试 Markdown 快捷输入', { checked: false }),
      b('todo', '拖动块左侧的 ⋮⋮ 手柄可调整顺序，点击手柄可转换类型 / 复制 / 删除', { checked: true }),
      b('h2', '页面树'),
      b('bullet', '点击左侧「新建页面」，或悬停在页面上点 + 创建子页面'),
      b('bullet', '拖动页面到另一个页面上，可调整层级和顺序'),
      b('h2', '搜索'),
      b('paragraph', '按 Ctrl/⌘ + K 打开全文搜索，支持中文和英文的子串匹配。'),
      b('quote', '内容会在停止输入约 0.8 秒后自动保存。'),
      b('code', 'function hello() {\n  return "你好，Knowbase"\n}'),
      b('divider'),
      b('paragraph', '')
    ],
    0
  )

  make(
    rootId,
    '块类型一览',
    '🧱',
    [
      b('h1', '标题 1'),
      b('h2', '标题 2'),
      b('h3', '标题 3'),
      b('paragraph', '普通文本段落。'),
      b('bullet', '无序列表项'),
      b('bullet', '另一项'),
      b('numbered', '有序列表项'),
      b('numbered', '自动编号'),
      b('todo', '待办事项', { checked: false }),
      b('quote', '引用块'),
      b('code', 'SELECT * FROM pages;'),
      b('divider'),
      b('paragraph', '')
    ],
    0
  )
}
