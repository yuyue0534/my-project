import { randomBytes } from 'node:crypto'

export const BLOCK_TYPES = ['paragraph', 'h1', 'h2', 'h3', 'todo', 'bullet', 'numbered', 'quote', 'code', 'divider']

export const uid = () => randomBytes(6).toString('hex')

export const newParagraph = (text = '') => ({ id: uid(), type: 'paragraph', text })

/** 校验并清洗客户端提交的块数组；非法返回 null */
export function sanitizeBlocks(input) {
  if (!Array.isArray(input) || input.length > 5000) return null
  const seen = new Set()
  const out = []
  for (const b of input) {
    if (!b || typeof b !== 'object') continue
    if (!BLOCK_TYPES.includes(b.type)) continue
    let id = typeof b.id === 'string' && b.id.length <= 40 ? b.id : uid()
    if (seen.has(id)) id = uid()
    seen.add(id)
    const block = { id, type: b.type, text: typeof b.text === 'string' ? b.text.slice(0, 200000) : '' }
    if (b.type === 'todo') block.checked = !!b.checked
    if (b.type === 'divider') block.text = ''
    out.push(block)
  }
  if (out.length === 0) out.push(newParagraph())
  return out
}

/** 抽取块数组中的纯文本，供全文搜索使用 */
export function extractText(blocks) {
  return blocks
    .filter((b) => b.type !== 'divider' && b.text)
    .map((b) => b.text)
    .join('\n')
}

/** 以第一个命中的关键词为中心截取摘要，返回 {before, match, after} 由前端安全渲染 */
export function makeSnippet(text, terms) {
  if (!text) return null
  const lower = text.toLowerCase()
  let pos = -1
  let len = 0
  for (const t of terms) {
    const p = lower.indexOf(t.toLowerCase())
    if (p >= 0 && (pos < 0 || p < pos)) {
      pos = p
      len = t.length
    }
  }
  if (pos < 0) return null
  const start = Math.max(0, pos - 30)
  const end = Math.min(text.length, pos + len + 70)
  const clean = (s) => s.replace(/\s+/g, ' ')
  return {
    before: (start > 0 ? '…' : '') + clean(text.slice(start, pos)),
    match: text.slice(pos, pos + len),
    after: clean(text.slice(pos + len, end)) + (end < text.length ? '…' : '')
  }
}
