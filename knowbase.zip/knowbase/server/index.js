import express from 'express'
import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'
import './db.js'
import authRoutes from './routes/auth.js'
import pageRoutes from './routes/pages.js'
import searchRoutes from './routes/search.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PORT = Number(process.env.PORT) || 3000
const HOST = process.env.HOST || '127.0.0.1' // 想让局域网访问：HOST=0.0.0.0 npm start
const distDir = path.join(__dirname, '..', 'dist')

const app = express()
app.use(express.json({ limit: '10mb' }))

app.use('/api/auth', authRoutes)
app.use('/api/pages', pageRoutes)
app.use('/api/search', searchRoutes)
app.use('/api', (req, res) => res.status(404).json({ error: '接口不存在' }))

if (fs.existsSync(path.join(distDir, 'index.html'))) {
  app.use(express.static(distDir))
  // SPA 回退：非 /api 的请求都返回 index.html，由前端路由接管
  app.use((req, res) => res.sendFile(path.join(distDir, 'index.html')))
} else {
  app.use((req, res) =>
    res.status(200).send('前端尚未构建。请先运行 npm run build，或使用 npm run dev 进入开发模式。')
  )
}

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || err.statusCode || 500
  if (status >= 500) console.error(err)
  res.status(status).json({ error: status >= 500 ? '服务器内部错误' : err.message })
})

app.listen(PORT, HOST, () => {
  console.log(`Knowbase 已启动：http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`)
})
