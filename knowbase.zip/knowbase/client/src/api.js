const TOKEN_KEY = 'kb_token'
export const getToken = () => localStorage.getItem(TOKEN_KEY)
export const setToken = (t) => (t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY))

async function request(method, url, body, opts = {}) {
  const headers = {}
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  const token = getToken()
  if (token) headers.Authorization = 'Bearer ' + token

  let res
  try {
    res = await fetch('/api' + url, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      keepalive: opts.keepalive // 页面关闭时也尽量把请求发出去
    })
  } catch {
    throw new Error('无法连接服务器，请检查网络或服务是否已启动')
  }
  let data = null
  try {
    data = await res.json()
  } catch {
    /* 非 JSON 响应 */
  }
  if (!res.ok) {
    if (res.status === 401 && !url.startsWith('/auth/login') && !url.startsWith('/auth/register')) {
      setToken(null)
      window.dispatchEvent(new Event('kb:unauthorized'))
    }
    const err = new Error(data?.error || `请求失败（${res.status}）`)
    err.status = res.status
    throw err
  }
  return data
}

export const api = {
  register: (email, password, name) => request('POST', '/auth/register', { email, password, name }),
  login: (email, password) => request('POST', '/auth/login', { email, password }),
  logout: () => request('POST', '/auth/logout', {}),
  me: () => request('GET', '/auth/me'),

  listPages: () => request('GET', '/pages'),
  createPage: (parent_id = null, title = '') => request('POST', '/pages', { parent_id, title }),
  getPage: (id) => request('GET', '/pages/' + id),
  updatePage: (id, patch, opts) => request('PUT', '/pages/' + id, patch, opts),
  deletePage: (id) => request('DELETE', '/pages/' + id),
  movePage: (id, target_id, position) => request('PATCH', `/pages/${id}/move`, { target_id, position }),

  search: (q) => request('GET', '/search?q=' + encodeURIComponent(q))
}
