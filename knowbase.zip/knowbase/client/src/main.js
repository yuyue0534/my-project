import { createApp } from 'vue'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-icons/font/bootstrap-icons.css'
import './styles.css'
import App from './App.vue'
import router from './router'
import { resetSession } from './store'

// 任何接口返回 401（会话过期）时，回到登录页
window.addEventListener('kb:unauthorized', () => {
  resetSession()
  if (router.currentRoute.value.path !== '/login') router.push('/login')
})

createApp(App).use(router).mount('#app')
