<script setup>
/**
 * 块编辑器（骨架版）
 * - 每个块一个自适应高度的 <textarea>：输入法 / 撤销 / 光标行为全部由浏览器原生处理，稳定可靠
 * - 数据：[{ id, type, text, checked? }]，通过 change 事件把同一个数组引用抛给父组件
 * - 后续升级为富文本时，只需替换 BlockRow 内部的文本输入层（例如换成 Tiptap），数据流和菜单逻辑可保留
 */
import { ref, reactive, computed, watch, nextTick, onMounted, onBeforeUnmount } from 'vue'
import BlockRow from './BlockRow.vue'
import { TYPES, newBlock } from '../blocks'

const props = defineProps({ initial: { type: Array, default: () => [] } })
const emit = defineEmits(['change'])

const root = ref(null)
const blocks = ref(props.initial.map((b) => ({ ...b })))
if (!blocks.value.length) blocks.value.push(newBlock())

watch(
  blocks,
  () => {
    if (!blocks.value.length) blocks.value.push(newBlock()) // 永远至少保留一个块
    emit('change', blocks.value)
  },
  { deep: true }
)

const idxOf = (id) => blocks.value.findIndex((b) => b.id === id)

// 有序列表编号：连续的 numbered 块从 1 开始计数
const numbers = computed(() => {
  let n = 0
  return blocks.value.map((b) => (b.type === 'numbered' ? ++n : ((n = 0), 0)))
})

/* ---------- 焦点 ---------- */
async function focusBlock(id, pos = 0) {
  await nextTick()
  const row = root.value?.querySelector(`[data-id="${id}"]`)
  if (!row) return
  const ta = row.querySelector('textarea')
  if (ta) {
    ta.focus()
    const p = pos === 'end' ? ta.value.length : Math.min(pos, ta.value.length)
    ta.setSelectionRange(p, p)
  } else {
    row.querySelector('.divider-focus')?.focus()
  }
}
function focusFirst() {
  if (blocks.value.length) focusBlock(blocks.value[0].id, 0)
}
defineExpose({ focusFirst })

/* ---------- 文本输入 & Markdown 快捷输入 ---------- */
function convert(b, type, checked = false) {
  b.type = type
  b.text = ''
  if (type === 'todo') b.checked = checked
  else delete b.checked
  if (type === 'divider') focusNextOrCreate(b)
  return true
}

// 仅当整行文本恰好等于触发串时才转换（避免误改已有内容）
function applyMarkdownShortcut(b) {
  const t = b.text
  if (b.type !== 'paragraph') return false
  if (t === '# ') return convert(b, 'h1')
  if (t === '## ') return convert(b, 'h2')
  if (t === '### ') return convert(b, 'h3')
  if (t === '- ' || t === '* ' || t === '+ ') return convert(b, 'bullet')
  if (/^\d{1,3}\. $/.test(t)) return convert(b, 'numbered')
  if (t === '[] ' || t === '[ ] ') return convert(b, 'todo')
  if (/^\[[xX]\] $/.test(t)) return convert(b, 'todo', true)
  if (t === '> ') return convert(b, 'quote')
  if (t === '```') return convert(b, 'code')
  if (t === '---' || t === '***') return convert(b, 'divider')
  return false
}

function onInput(b, text) {
  b.text = text
  if (applyMarkdownShortcut(b)) {
    slash.open = false
    if (b.type !== 'divider') focusBlock(b.id, 0)
    return
  }
  updateSlash(b)
}

function focusNextOrCreate(b) {
  const i = idxOf(b.id)
  let next = blocks.value[i + 1]
  if (!next) {
    next = newBlock()
    blocks.value.push(next)
  }
  focusBlock(next.id, 0)
}

/* ---------- 斜杠菜单 ---------- */
const slash = reactive({ open: false, blockId: null, query: '', index: 0, top: 0 })
const slashItems = computed(() => {
  const q = slash.query.toLowerCase()
  return TYPES.filter((t) => !q || t.label.includes(q) || t.keywords.includes(q))
})

function updateSlash(b) {
  const m = /^\/([^\s/]*)$/.exec(b.text)
  if (m && b.type !== 'code' && b.type !== 'divider') {
    if (slash.blockId !== b.id || slash.query !== m[1]) slash.index = 0
    slash.open = true
    slash.blockId = b.id
    slash.query = m[1]
    if (!slashItems.value.length) slash.open = false
    nextTick(() => {
      const row = root.value?.querySelector(`[data-id="${b.id}"]`)
      if (row) slash.top = row.offsetTop + row.offsetHeight + 4
    })
  } else if (slash.open && slash.blockId === b.id) {
    slash.open = false
  }
}

function applyCommand(b, item) {
  slash.open = false
  b.text = ''
  b.type = item.type
  if (item.type === 'todo') b.checked = false
  else delete b.checked
  if (item.type === 'divider') focusNextOrCreate(b)
  else focusBlock(b.id, 0)
}

function onBlur(b) {
  if (slash.open && slash.blockId === b.id) slash.open = false
}

watch(
  () => slash.index,
  () => nextTick(() => root.value?.querySelector('.slash-item.active')?.scrollIntoView({ block: 'nearest' }))
)

/* ---------- 键盘 ---------- */
const CONTINUE_TYPES = ['bullet', 'numbered', 'todo'] // 回车后继续同类型
const EMPTY_EXIT_TYPES = ['bullet', 'numbered', 'todo', 'quote'] // 空行回车退出为段落

function onKeydown(e, b) {
  if (e.isComposing || e.keyCode === 229) return // 输入法组词中，不拦截
  const i = idxOf(b.id)
  const mod = e.ctrlKey || e.metaKey

  // 斜杠菜单优先处理
  if (slash.open && slash.blockId === b.id) {
    const items = slashItems.value
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      slash.index = (slash.index + 1) % items.length
      return
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      slash.index = (slash.index + items.length - 1) % items.length
      return
    }
    if (e.key === 'Enter' || e.key === 'Tab') {
      e.preventDefault()
      applyCommand(b, items[slash.index])
      return
    }
    if (e.key === 'Escape') {
      e.preventDefault()
      slash.open = false
      return
    }
  }

  // Ctrl/⌘ + Shift + ↑/↓：移动块
  if (mod && e.shiftKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
    e.preventDefault()
    const j = e.key === 'ArrowUp' ? i - 1 : i + 1
    if (j >= 0 && j < blocks.value.length) {
      const [item] = blocks.value.splice(i, 1)
      blocks.value.splice(j, 0, item)
      focusBlock(b.id, 'end')
    }
    return
  }

  if (b.type === 'divider') return onDividerKey(e, b, i)

  const ta = e.target
  const selStart = ta.selectionStart
  const selEnd = ta.selectionEnd

  switch (e.key) {
    case 'Enter': {
      if (b.type === 'code' && !e.shiftKey && !mod) return // 代码块内回车 = 换行
      if (b.type !== 'code' && e.shiftKey) return // 其它块 Shift+Enter = 块内换行
      e.preventDefault()
      if (b.type === 'code') {
        // 代码块中 Shift/Ctrl+Enter：在下方新建段落，跳出代码块
        const nb = newBlock()
        blocks.value.splice(i + 1, 0, nb)
        focusBlock(nb.id, 0)
        return
      }
      if (EMPTY_EXIT_TYPES.includes(b.type) && b.text === '') {
        b.type = 'paragraph'
        delete b.checked
        return
      }
      const before = b.text.slice(0, selStart)
      const after = b.text.slice(selEnd)
      b.text = before
      const nb = newBlock(CONTINUE_TYPES.includes(b.type) ? b.type : 'paragraph', after)
      blocks.value.splice(i + 1, 0, nb)
      focusBlock(nb.id, 0)
      return
    }

    case 'Backspace': {
      if (selStart !== 0 || selEnd !== 0) return
      if (b.type !== 'paragraph') {
        e.preventDefault()
        b.type = 'paragraph'
        delete b.checked
        return
      }
      if (i > 0) {
        e.preventDefault()
        const prev = blocks.value[i - 1]
        if (prev.type === 'divider') {
          blocks.value.splice(i - 1, 1)
          focusBlock(b.id, 0)
        } else {
          const pos = prev.text.length
          prev.text += b.text
          blocks.value.splice(i, 1)
          focusBlock(prev.id, pos)
        }
      }
      return
    }

    case 'Delete': {
      const next = blocks.value[i + 1]
      if (selStart === b.text.length && selEnd === b.text.length && next && next.type !== 'divider') {
        e.preventDefault()
        const pos = b.text.length
        b.text += next.text
        blocks.value.splice(i + 1, 1)
        focusBlock(b.id, pos)
      }
      return
    }

    case 'ArrowUp':
      if (!e.shiftKey && !mod && selStart === 0 && selEnd === 0 && i > 0) {
        e.preventDefault()
        focusBlock(blocks.value[i - 1].id, 'end')
      }
      return

    case 'ArrowDown':
      if (!e.shiftKey && !mod && selStart === b.text.length && selEnd === b.text.length && i < blocks.value.length - 1) {
        e.preventDefault()
        focusBlock(blocks.value[i + 1].id, 0)
      }
      return

    case 'Tab':
      if (b.type === 'code') {
        e.preventDefault()
        ta.setRangeText('  ', selStart, selEnd, 'end')
        b.text = ta.value
      }
      return
  }
}

function onDividerKey(e, b, i) {
  if (e.key === 'Backspace' || e.key === 'Delete') {
    e.preventDefault()
    blocks.value.splice(i, 1)
    const target = blocks.value[Math.max(0, i - 1)]
    if (target) focusBlock(target.id, 'end')
  } else if (e.key === 'Enter') {
    e.preventDefault()
    const nb = newBlock()
    blocks.value.splice(i + 1, 0, nb)
    focusBlock(nb.id, 0)
  } else if (e.key === 'ArrowUp' && i > 0) {
    e.preventDefault()
    focusBlock(blocks.value[i - 1].id, 'end')
  } else if (e.key === 'ArrowDown' && i < blocks.value.length - 1) {
    e.preventDefault()
    focusBlock(blocks.value[i + 1].id, 0)
  }
}

/* ---------- "+" 按钮：在下方插入并打开斜杠菜单 ---------- */
function addBelow(b) {
  if (b.type === 'paragraph' && b.text === '') {
    b.text = '/'
    updateSlash(b)
    focusBlock(b.id, 'end')
    return
  }
  const nb = newBlock('paragraph', '/')
  blocks.value.splice(idxOf(b.id) + 1, 0, nb)
  updateSlash(nb)
  focusBlock(nb.id, 'end')
}

/* ---------- 底部空白区域：点击后在末尾继续写 ---------- */
function onTailClick() {
  const last = blocks.value[blocks.value.length - 1]
  if (last && last.type === 'paragraph' && last.text === '') return focusBlock(last.id, 0)
  const nb = newBlock()
  blocks.value.push(nb)
  focusBlock(nb.id, 0)
}

/* ---------- 块菜单（点击 ⋮⋮） ---------- */
const menu = reactive({ open: false, blockId: null, top: 0, left: 0 })

function openMenu(b, e) {
  const r = e.currentTarget.getBoundingClientRect()
  const rr = root.value.getBoundingClientRect()
  const same = menu.open && menu.blockId === b.id
  menu.blockId = b.id
  menu.top = r.bottom - rr.top + 4
  menu.left = Math.max(0, r.left - rr.left)
  menu.open = !same
}
function turnInto(type) {
  const b = blocks.value[idxOf(menu.blockId)]
  menu.open = false
  if (!b) return
  b.type = type
  if (type === 'todo') b.checked = !!b.checked
  else delete b.checked
  if (type === 'divider') {
    b.text = ''
    focusNextOrCreate(b)
  } else focusBlock(b.id, 'end')
}
function duplicateBlock() {
  const i = idxOf(menu.blockId)
  menu.open = false
  if (i < 0) return
  const copy = { ...blocks.value[i], id: newBlock().id }
  blocks.value.splice(i + 1, 0, copy)
  focusBlock(copy.id, 'end')
}
function deleteBlock() {
  const i = idxOf(menu.blockId)
  menu.open = false
  if (i < 0) return
  blocks.value.splice(i, 1)
  const target = blocks.value[Math.max(0, i - 1)]
  if (target) focusBlock(target.id, 'end')
}
function onWindowMouseDown(e) {
  if (!e.target.closest?.('.floating-menu') && !e.target.closest?.('.gutter-btn')) menu.open = false
}
onMounted(() => window.addEventListener('mousedown', onWindowMouseDown))
onBeforeUnmount(() => window.removeEventListener('mousedown', onWindowMouseDown))

/* ---------- 拖拽排序 ---------- */
const drag = reactive({ id: null, overId: null, pos: null })

function onDragStart(b, e) {
  drag.id = b.id
  menu.open = false
  e.dataTransfer.effectAllowed = 'move'
  e.dataTransfer.setData('text/plain', b.id)
  const row = e.currentTarget.closest('.block-row')
  if (row) e.dataTransfer.setDragImage(row, 0, 0)
}
function onDragOver(b, e) {
  if (!drag.id) return // 不是块拖拽（例如侧边栏页面拖拽）则忽略
  e.preventDefault()
  const r = e.currentTarget.getBoundingClientRect()
  drag.overId = b.id
  drag.pos = e.clientY < r.top + r.height / 2 ? 'before' : 'after'
}
function onDrop(e) {
  if (!drag.id) return
  e.preventDefault()
  const from = idxOf(drag.id)
  if (from >= 0 && drag.overId && drag.overId !== drag.id) {
    const [item] = blocks.value.splice(from, 1)
    let to = blocks.value.findIndex((x) => x.id === drag.overId)
    if (drag.pos === 'after') to++
    blocks.value.splice(to, 0, item)
  }
  onDragEnd()
}
function onDragEnd() {
  drag.id = drag.overId = drag.pos = null
}
const dropPosOf = (b) => (drag.id && drag.overId === b.id && drag.id !== b.id ? drag.pos : null)
</script>

<template>
  <div ref="root" class="editor">
    <BlockRow
      v-for="(b, i) in blocks"
      :key="b.id"
      :block="b"
      :number="numbers[i]"
      :drop-pos="dropPosOf(b)"
      @input="(t) => onInput(b, t)"
      @keydown="(e) => onKeydown(e, b)"
      @toggle="(v) => (b.checked = v)"
      @add="addBelow(b)"
      @menu="(e) => openMenu(b, e)"
      @drag-start="(e) => onDragStart(b, e)"
      @drag-end="onDragEnd"
      @drag-over="(e) => onDragOver(b, e)"
      @drop="onDrop"
      @blur="onBlur(b)"
    />
    <div class="editor-tail" @click="onTailClick"></div>

    <!-- 斜杠命令菜单：mousedown.prevent 避免输入框失焦 -->
    <div v-if="slash.open" class="floating-menu slash-menu" :style="{ top: slash.top + 'px' }" @mousedown.prevent>
      <div class="menu-title">基础块</div>
      <button
        v-for="(t, i) in slashItems"
        :key="t.type"
        type="button"
        class="slash-item"
        :class="{ active: i === slash.index }"
        @mousemove="slash.index = i"
        @click="applyCommand(blocks[idxOf(slash.blockId)], t)"
      >
        <span class="slash-icon"><i class="bi" :class="t.icon"></i></span>
        <span class="slash-text">
          <span class="slash-label">{{ t.label }}</span>
          <span class="slash-desc">{{ t.desc }}</span>
        </span>
      </button>
    </div>

    <!-- 块菜单 -->
    <div v-if="menu.open" class="floating-menu block-menu" :style="{ top: menu.top + 'px', left: menu.left + 'px' }">
      <div class="menu-title">转换为</div>
      <button v-for="t in TYPES" :key="t.type" type="button" class="menu-item" @click="turnInto(t.type)">
        <i class="bi" :class="t.icon"></i>{{ t.label }}
      </button>
      <div class="menu-sep"></div>
      <button type="button" class="menu-item" @click="duplicateBlock"><i class="bi bi-files"></i>复制</button>
      <button type="button" class="menu-item danger" @click="deleteBlock"><i class="bi bi-trash"></i>删除</button>
    </div>
  </div>
</template>
