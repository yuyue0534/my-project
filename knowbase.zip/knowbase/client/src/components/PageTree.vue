<script setup>
import PageTreeItem from './PageTreeItem.vue'
import { store, tree, movePage } from '../store'

async function dropToRoot() {
  const id = store.dragId
  store.dragId = null
  if (id) await movePage(id, null, 'root')
}
</script>

<template>
  <div class="page-tree">
    <div v-if="!tree.length" class="px-3 py-2 small text-muted">还没有页面</div>
    <PageTreeItem v-for="node in tree" :key="node.id" :node="node" :depth="0" />
    <div v-if="store.dragId" class="root-drop" @dragover.prevent @drop.prevent="dropToRoot">拖到这里，移到顶层</div>
  </div>
</template>
