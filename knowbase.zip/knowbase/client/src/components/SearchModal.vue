<script setup>
import { ref, watch, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '../api'

const props = defineProps({ open: Boolean })
const emit = defineEmits(['close'])
const router = useRouter()

const q = ref('')
const results = ref([])
const active = ref(0)
const loading = ref(false)
const searched = ref(false)
const input = ref(null)
const list = ref(null)
let timer = null
let seq = 0

watch(
  () => props.open,
  async (v) => {
    if (!v) return
    q.value = ''
    results.value = []
    active.value = 0
    searched.value = false
    await nextTick()
    input.value?.focus()
  }
)

watch(q, (v) => {
  clearTimeout(timer)
  if (!v.trim()) {
    results.value = []
    searched.value = false
    return
  }
  timer = setTimeout(run, 180)
})

async function run() {
  const my = ++seq
  loading.value = true
  try {
    const r = await api.search(q.value.trim())
    if (my !== seq) return
    results.value = r.results
    active.value = 0
    searched.value = true
  } catch {
    if (my === seq) results.value = []
  } finally {
    if (my === seq) loading.value = false
  }
}

function go(r) {
  emit('close')
  router.push('/p/' + r.id)
}

function onKeydown(e) {
  if (e.isComposing || e.keyCode === 229) return
  if (e.key === 'Escape') return emit('close')
  if (!results.value.length) return
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault()
    const n = results.value.length
    active.value = (active.value + (e.key === 'ArrowDown' ? 1 : n - 1)) % n
    nextTick(() => list.value?.querySelector('.active')?.scrollIntoView({ block: 'nearest' }))
  } else if (e.key === 'Enter') {
    e.preventDefault()
    go(results.value[active.value])
  }
}
</script>

<template>
  <Teleport to="body">
    <div v-if="open" class="search-overlay" @mousedown.self="emit('close')">
      <div class="search-dialog" role="dialog" aria-label="搜索">
        <div class="search-input-row">
          <i class="bi bi-search"></i>
          <input
            ref="input"
            v-model="q"
            class="search-input"
            placeholder="搜索标题和正文…"
            autocomplete="off"
            @keydown="onKeydown"
          />
          <span v-if="loading" class="spinner-border spinner-border-sm text-secondary"></span>
        </div>
        <div ref="list" class="search-results">
          <button
            v-for="(r, i) in results"
            :key="r.id"
            class="search-item"
            :class="{ active: i === active }"
            @mousemove="active = i"
            @click="go(r)"
          >
            <span class="search-item-icon">{{ r.icon || '📄' }}</span>
            <span class="search-item-body">
              <span class="search-item-title">{{ r.title || '无标题' }}</span>
              <span v-if="r.snippet" class="search-item-snippet">
                {{ r.snippet.before }}<mark>{{ r.snippet.match }}</mark>{{ r.snippet.after }}
              </span>
            </span>
          </button>
          <div v-if="searched && !results.length" class="search-hint">没有找到「{{ q }}」相关的页面</div>
          <div v-else-if="!q.trim()" class="search-hint">输入关键词，多个词用空格分隔（需同时命中）</div>
        </div>
      </div>
    </div>
  </Teleport>
</template>
