<script setup>
import { ref, watch, nextTick, onMounted, onBeforeUnmount } from 'vue'
import { PLACEHOLDERS } from '../blocks'
import { autosize } from '../autosize'

const props = defineProps({
  block: { type: Object, required: true },
  number: { type: Number, default: 0 },
  dropPos: { type: String, default: null } // before | after | null
})
const emit = defineEmits(['input', 'keydown', 'toggle', 'add', 'menu', 'drag-start', 'drag-end', 'drag-over', 'drop', 'blur'])

const ta = ref(null)
const resize = () => autosize(ta.value)

watch(() => [props.block.text, props.block.type], () => nextTick(resize))
onMounted(() => {
  resize()
  window.addEventListener('resize', resize)
})
onBeforeUnmount(() => window.removeEventListener('resize', resize))

function onDragStart(e) {
  emit('drag-start', e)
}
</script>

<template>
  <div
    class="block-row"
    :class="dropPos && 'drop-' + dropPos"
    :data-id="block.id"
    @dragover="(e) => emit('drag-over', e)"
    @drop="(e) => emit('drop', e)"
  >
    <div class="block-gutter">
      <button type="button" class="gutter-btn" title="在下方添加块" @click="emit('add')">
        <i class="bi bi-plus-lg"></i>
      </button>
      <button
        type="button"
        class="gutter-btn"
        title="拖动排序，点击打开菜单"
        draggable="true"
        @dragstart="onDragStart"
        @dragend="emit('drag-end')"
        @click="(e) => emit('menu', e)"
      >
        <i class="bi bi-grip-vertical"></i>
      </button>
    </div>

    <div class="block-content" :class="['bt-' + block.type, { done: block.type === 'todo' && block.checked }]">
      <div v-if="block.type === 'divider'" class="divider-focus" tabindex="0" @keydown="(e) => emit('keydown', e)">
        <hr />
      </div>
      <template v-else>
        <span v-if="block.type === 'bullet'" class="marker">•</span>
        <span v-else-if="block.type === 'numbered'" class="marker">{{ number }}.</span>
        <input
          v-else-if="block.type === 'todo'"
          type="checkbox"
          class="form-check-input todo-box"
          :checked="!!block.checked"
          @change="(e) => emit('toggle', e.target.checked)"
        />
        <textarea
          ref="ta"
          rows="1"
          :value="block.text"
          :placeholder="PLACEHOLDERS[block.type]"
          spellcheck="false"
          @input="(e) => emit('input', e.target.value)"
          @keydown="(e) => emit('keydown', e)"
          @blur="emit('blur')"
        ></textarea>
      </template>
    </div>
  </div>
</template>
