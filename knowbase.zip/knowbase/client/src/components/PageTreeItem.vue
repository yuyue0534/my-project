<script setup>
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { store, isExpanded, toggleExpand, createPage, removePage, movePage, isDescendant } from '../store'

const props = defineProps({ node: Object, depth: Number })
const route = useRoute()
const router = useRouter()

const active = computed(() => route.params.id === props.node.id)
const expanded = computed(() => isExpanded(props.node.id))
const dropPos = ref(null) // before | after | inside

function open() {
  router.push('/p/' + props.node.id)
}

async function addChild() {
  const p = await createPage(props.node.id)
  router.push('/p/' + p.id)
}

async function remove() {
  const n = props.node.children.length
  const name = props.node.title || '无标题'
  const msg = n
    ? `删除「${name}」及其 ${n} 个直接子页面？此操作不可恢复。`
    : `删除「${name}」？此操作不可恢复。`
  if (!window.confirm(msg)) return
  const gone = await removePage(props.node.id)
  if (gone.has(route.params.id)) router.push('/')
}

/* ---------- 拖拽排序 / 嵌套 ---------- */
function onDragStart(e) {
  store.dragId = props.node.id
  e.dataTransfer.effectAllowed = 'move'
  e.dataTransfer.setData('text/plain', props.node.id)
}
function onDragEnd() {
  store.dragId = null
  dropPos.value = null
}
function onDragOver(e) {
  const dragId = store.dragId
  if (!dragId || dragId === props.node.id || isDescendant(props.node.id, dragId)) return
  e.preventDefault()
  const r = e.currentTarget.getBoundingClientRect()
  const ratio = (e.clientY - r.top) / r.height
  dropPos.value = ratio < 0.25 ? 'before' : ratio > 0.75 ? 'after' : 'inside'
}
function onDragLeave(e) {
  if (!e.currentTarget.contains(e.relatedTarget)) dropPos.value = null
}
async function onDrop(e) {
  const dragId = store.dragId
  const pos = dropPos.value
  dropPos.value = null
  store.dragId = null
  if (!dragId || !pos || dragId === props.node.id) return
  e.preventDefault()
  try {
    await movePage(dragId, props.node.id, pos)
  } catch (err) {
    window.alert(err.message)
  }
}
</script>

<template>
  <div>
    <div
      class="tree-row"
      :class="[{ active }, dropPos && 'drop-' + dropPos]"
      :style="{ paddingLeft: 6 + depth * 14 + 'px' }"
      draggable="true"
      @click="open"
      @dragstart="onDragStart"
      @dragend="onDragEnd"
      @dragover="onDragOver"
      @dragleave="onDragLeave"
      @drop="onDrop"
    >
      <button class="tree-caret" type="button" :aria-label="expanded ? '收起' : '展开'" @click.stop="toggleExpand(node.id)">
        <i class="bi" :class="expanded ? 'bi-chevron-down' : 'bi-chevron-right'"></i>
      </button>
      <span class="tree-icon">{{ node.icon || '📄' }}</span>
      <span class="tree-title text-truncate">{{ node.title || '无标题' }}</span>
      <span class="tree-actions">
        <button type="button" title="添加子页面" @click.stop="addChild"><i class="bi bi-plus-lg"></i></button>
        <button type="button" title="删除页面" @click.stop="remove"><i class="bi bi-trash"></i></button>
      </span>
    </div>

    <template v-if="expanded">
      <PageTreeItem v-for="child in node.children" :key="child.id" :node="child" :depth="depth + 1" />
      <div v-if="!node.children.length" class="tree-empty" :style="{ paddingLeft: 30 + depth * 14 + 'px' }">无子页面</div>
    </template>
  </div>
</template>
