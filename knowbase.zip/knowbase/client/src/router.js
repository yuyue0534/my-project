import { createRouter, createWebHistory } from 'vue-router'
import { store, initAuth } from './store'
import AuthView from './views/AuthView.vue'
import WorkspaceView from './views/WorkspaceView.vue'
import HomeView from './views/HomeView.vue'
import PageView from './views/PageView.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', component: AuthView, meta: { public: true, mode: 'login' } },
    { path: '/register', component: AuthView, meta: { public: true, mode: 'register' } },
    {
      path: '/',
      component: WorkspaceView,
      children: [
        { path: '', name: 'home', component: HomeView },
        { path: 'p/:id', name: 'page', component: PageView }
      ]
    },
    { path: '/:pathMatch(.*)*', redirect: '/' }
  ]
})

router.beforeEach(async (to) => {
  if (!store.authChecked) await initAuth()
  if (to.meta.public) return store.user ? '/' : true
  if (!store.user) return '/login'
  return true
})

export default router
