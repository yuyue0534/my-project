// 块类型定义：编辑器、斜杠菜单、块菜单共用

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4)

export const newBlock = (type = 'paragraph', text = '') => {
  const b = { id: uid(), type, text }
  if (type === 'todo') b.checked = false
  return b
}

export const TYPES = [
  { type: 'paragraph', label: '文本', desc: '普通段落', icon: 'bi-text-paragraph', keywords: 'text paragraph p wenben' },
  { type: 'h1', label: '标题 1', desc: '大标题', icon: 'bi-type-h1', keywords: 'h1 heading1 title biaoti' },
  { type: 'h2', label: '标题 2', desc: '中标题', icon: 'bi-type-h2', keywords: 'h2 heading2' },
  { type: 'h3', label: '标题 3', desc: '小标题', icon: 'bi-type-h3', keywords: 'h3 heading3' },
  { type: 'todo', label: '待办清单', desc: '带复选框的任务', icon: 'bi-check2-square', keywords: 'todo task checkbox daiban' },
  { type: 'bullet', label: '无序列表', desc: '项目符号列表', icon: 'bi-list-ul', keywords: 'bullet list ul liebiao' },
  { type: 'numbered', label: '有序列表', desc: '自动编号列表', icon: 'bi-list-ol', keywords: 'numbered number ol list' },
  { type: 'quote', label: '引用', desc: '强调一段引用', icon: 'bi-quote', keywords: 'quote blockquote yinyong' },
  { type: 'code', label: '代码块', desc: '等宽字体，Tab 缩进', icon: 'bi-code-slash', keywords: 'code pre daima' },
  { type: 'divider', label: '分割线', desc: '分隔内容', icon: 'bi-hr', keywords: 'divider hr line fengexian' }
]

export const PLACEHOLDERS = {
  paragraph: "输入文字，或按 '/' 选择块类型",
  h1: '标题 1',
  h2: '标题 2',
  h3: '标题 3',
  todo: '待办事项',
  bullet: '列表项',
  numbered: '列表项',
  quote: '引用',
  code: '代码'
}

export const EMOJIS = [
  '📄', '📝', '📚', '📖', '📌', '📎', '💡', '🎯', '🚀', '🧠', '🧱', '🗂️',
  '📅', '✅', '⭐', '🔥', '🌱', '🌍', '🎨', '🎵', '💼', '🛠️', '🔬', '🧪',
  '🏠', '✈️', '🍜', '☕', '❤️', '😀', '👋', '🐱'
]
