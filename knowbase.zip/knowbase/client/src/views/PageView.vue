<script setup>
import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import BlockEditor from '../components/BlockEditor.vue'
import { api } from '../api'
import { store, hooks, patchPage, rememberPage } from '../store'
import { EMOJIS } from '../blocks'
import { autosize } from '../autosize'

const route = useRoute()
const pageId = route.params.id // 路由用 :key 区分页面，本组件实例只服务一个页面

const loading = ref(true)
const error = ref('')
const title = ref('')
const icon = ref('')
const initialBlocks = ref([])
const pickerOpen = ref(false)
const titleEl = ref(null)
const editor = ref(null)

/* ---------- 自动保存：防抖 + 离开页面时立即保存 ---------- */
let dirty = {}
let timer = null
let currentContent = null // 编辑器数组的引用，保存时取最新值
const SAVE_DELAY = 800

function mark(patch) {
  Object.assign(dirty, patch)
  store.saveStatus = 'dirty'
  clearTimeout(timer)
  timer = setTimeout(() => flush(), SAVE_DELAY)
}

async function flush(opts) {
  clearTimeout(timer)
  if (!Object.keys(dirty).length) return
  const patch = { ...dirty }
  if ('content' in patch) patch.content = currentContent
  dirty = {}
  store.saveStatus = 'saving'
  try {
    await api.updatePage(pageId, patch, opts)
    if (!Object.keys(dirty).length) store.saveStatus = 'saved'
  } catch (e) {
    dirty = { ...patch, ...dirty } // 失败则放回，稍后重试
    store.saveStatus = 'error'
    if (e.status !== 401) timer = setTimeout(() => flush(), 4000)
  }
}

function onTitleInput() {
  autosize(titleEl.value)
  patchPage(pageId, { title: title.value }) // 侧边栏即时同步
  mark({ title: title.value })
}
function pickIcon(e) {
  icon.value = e
  pickerOpen.value = false
  patchPage(pageId, { icon: e })
  mark({ icon: e })
}
function onBlocks(blocks) {
  currentContent = blocks
  mark({ content: true })
}
function onTitleEnter() {
  editor.value?.focusFirst()
}

const onBeforeUnload = () => flush({ keepalive: true })

onMounted(async () => {
  hooks.flush = () => flush()
  window.addEventListener('beforeunload', onBeforeUnload)
  window.addEventListener('mousedown', closePicker)
  try {
    const { page } = await api.getPage(pageId)
    title.value = page.title
    icon.value = page.icon
    initialBlocks.value = page.content
    currentContent = page.content
    store.saveStatus = 'idle'
    rememberPage(pageId)
    loading.value = false
    await nextTick()
    autosize(titleEl.value)
    if (!page.title) titleEl.value?.focus() // 新建的空白页面：直接输入标题
  } catch (e) {
    error.value = e.status === 404 ? '这个页面不存在，可能已被删除。' : e.message
    loading.value = false
  }
})

onBeforeUnmount(() => {
  if (hooks.flush) hooks.flush = null
  window.removeEventListener('beforeunload', onBeforeUnload)
  window.removeEventListener('mousedown', closePicker)
  flush({ keepalive: true })
})

function closePicker(e) {
  if (!e.target.closest?.('.icon-wrap')) pickerOpen.value = false
}
</script>

<template>
  <div v-if="loading" class="page-wrap text-muted pt-5">加载中…</div>
  <div v-else-if="error" class="empty-state">
    <div class="empty-icon">🫥</div>
    <h2>{{ error }}</h2>
    <router-link to="/" class="btn btn-outline-secondary">返回首页</router-link>
  </div>
  <div v-else class="page-wrap">
    <div class="icon-wrap">
      <button class="page-icon" type="button" title="更换图标" @click="pickerOpen = !pickerOpen">{{ icon || '📄' }}</button>
      <div v-if="pickerOpen" class="floating-menu emoji-picker">
        <button v-for="e in EMOJIS" :key="e" type="button" class="emoji-btn" @click="pickIcon(e)">{{ e }}</button>
      </div>
    </div>

    <textarea
      ref="titleEl"
      v-model="title"
      class="page-title"
      rows="1"
      placeholder="无标题"
      @input="onTitleInput"
      @keydown.enter.exact.prevent="onTitleEnter"
    ></textarea>

    <BlockEditor ref="editor" :initial="initialBlocks" @change="onBlocks" />
  </div>
</template>
