<script setup>
import { watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { store, tree, getPage, lastPageId, createPage } from '../store'

const router = useRouter()

function redirectIfPossible() {
  if (!store.pagesLoaded) return
  const last = lastPageId()
  if (last && getPage(last)) return router.replace('/p/' + last)
  if (tree.value.length) router.replace('/p/' + tree.value[0].id)
}
onMounted(redirectIfPossible)
watch(() => store.pagesLoaded, redirectIfPossible)

async function create() {
  const p = await createPage(null)
  router.push('/p/' + p.id)
}
</script>

<template>
  <div class="empty-state">
    <div class="empty-icon">🗒️</div>
    <h2>还没有页面</h2>
    <p>新建第一个页面，开始记录。</p>
    <button class="btn btn-accent" @click="create"><i class="bi bi-plus-lg me-1"></i>新建页面</button>
  </div>
</template>
