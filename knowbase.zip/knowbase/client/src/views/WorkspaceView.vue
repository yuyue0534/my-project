<script setup>
import { ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import PageTree from '../components/PageTree.vue'
import SearchModal from '../components/SearchModal.vue'
import { store, loadPages, createPage, logout, ancestorsOf, expandAncestors } from '../store'

const route = useRoute()
const router = useRouter()
const searchOpen = ref(false)
const sidebarOpen = ref(false)
const userMenuOpen = ref(false)
const loadError = ref('')

const crumbs = computed(() => (route.params.id ? ancestorsOf(route.params.id) : []))
const statusText = computed(
  () => ({ dirty: '未保存…', saving: '保存中…', saved: '已保存', error: '保存失败，将自动重试' })[store.saveStatus] || ''
)

onMounted(async () => {
  window.addEventListener('keydown', onKey)
  window.addEventListener('mousedown', closeUserMenu)
  try {
    await loadPages()
  } catch (e) {
    loadError.value = e.message
  }
})
onBeforeUnmount(() => {
  window.removeEventListener('keydown', onKey)
  window.removeEventListener('mousedown', closeUserMenu)
})

// 切换页面时：展开祖先节点，并在移动端收起侧边栏
watch(
  () => [route.params.id, store.pagesLoaded],
  () => {
    if (route.params.id && store.pagesLoaded) expandAncestors(route.params.id)
    sidebarOpen.value = false
  },
  { immediate: true }
)

function onKey(e) {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault()
    searchOpen.value = true
  }
}
function closeUserMenu(e) {
  if (!e.target.closest?.('.user-menu-wrap')) userMenuOpen.value = false
}

async function newPage() {
  const p = await createPage(null)
  router.push('/p/' + p.id)
}
async function doLogout() {
  await logout()
  router.push('/login')
}
</script>

<template>
  <div class="app-shell">
    <div v-if="sidebarOpen" class="sidebar-backdrop" @click="sidebarOpen = false"></div>

    <aside class="sidebar" :class="{ open: sidebarOpen }">
      <div class="user-menu-wrap">
        <button class="user-btn" @click="userMenuOpen = !userMenuOpen">
          <span class="avatar">{{ (store.user?.name || '?').slice(0, 1).toUpperCase() }}</span>
          <span class="user-name text-truncate">{{ store.user?.name }} 的知识库</span>
          <i class="bi bi-chevron-expand ms-auto small"></i>
        </button>
        <div v-if="userMenuOpen" class="floating-menu user-menu">
          <div class="px-3 py-2 small text-muted text-truncate">{{ store.user?.email }}</div>
          <button class="menu-item" @click="doLogout"><i class="bi bi-box-arrow-right"></i>退出登录</button>
        </div>
      </div>

      <div class="sidebar-actions">
        <button class="side-btn" @click="searchOpen = true">
          <i class="bi bi-search"></i><span>搜索</span><kbd class="ms-auto">Ctrl K</kbd>
        </button>
        <button class="side-btn" @click="newPage"><i class="bi bi-plus-square"></i><span>新建页面</span></button>
      </div>

      <div class="sidebar-label">页面</div>
      <div class="sidebar-tree">
        <PageTree v-if="store.pagesLoaded" />
        <div v-else-if="loadError" class="px-3 small text-danger">{{ loadError }}</div>
        <div v-else class="px-3 small text-muted">加载中…</div>
      </div>
    </aside>

    <main class="main">
      <header class="topbar">
        <button class="icon-btn d-md-none" @click="sidebarOpen = true" aria-label="打开侧边栏">
          <i class="bi bi-list fs-5"></i>
        </button>
        <nav class="crumbs text-truncate">
          <template v-for="(c, i) in crumbs" :key="c.id">
            <i v-if="i" class="bi bi-chevron-right crumb-sep"></i>
            <router-link :to="'/p/' + c.id" class="crumb">
              <span>{{ c.icon || '📄' }}</span> {{ c.title || '无标题' }}
            </router-link>
          </template>
        </nav>
        <span class="save-status" :class="store.saveStatus">{{ statusText }}</span>
      </header>

      <div class="main-scroll">
        <router-view v-if="store.pagesLoaded" :key="route.params.id || 'home'" />
      </div>
    </main>

    <SearchModal :open="searchOpen" @close="searchOpen = false" />
  </div>
</template>
