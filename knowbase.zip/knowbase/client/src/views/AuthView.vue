<script setup>
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { login, register } from '../store'

const route = useRoute()
const router = useRouter()
const isRegister = computed(() => route.meta.mode === 'register')

const name = ref('')
const email = ref('')
const password = ref('')
const error = ref('')
const busy = ref(false)

async function submit() {
  error.value = ''
  busy.value = true
  try {
    if (isRegister.value) await register(email.value, password.value, name.value)
    else await login(email.value, password.value)
    router.push('/')
  } catch (e) {
    error.value = e.message
  } finally {
    busy.value = false
  }
}
</script>

<template>
  <div class="auth-page">
    <div class="auth-card">
      <div class="auth-logo">📚</div>
      <h1 class="auth-title">{{ isRegister ? '创建账号' : '登录 Knowbase' }}</h1>
      <p class="auth-sub">{{ isRegister ? '注册后会自动生成一份示例页面' : '你的页面、笔记和想法都在这里' }}</p>

      <form @submit.prevent="submit" novalidate>
        <div v-if="isRegister" class="mb-3">
          <label class="form-label" for="name">昵称</label>
          <input id="name" v-model="name" class="form-control" autocomplete="nickname" placeholder="可选" />
        </div>
        <div class="mb-3">
          <label class="form-label" for="email">邮箱</label>
          <input id="email" v-model="email" type="email" class="form-control" autocomplete="email" required autofocus />
        </div>
        <div class="mb-3">
          <label class="form-label" for="password">密码</label>
          <input
            id="password"
            v-model="password"
            type="password"
            class="form-control"
            :autocomplete="isRegister ? 'new-password' : 'current-password'"
            :placeholder="isRegister ? '至少 6 位' : ''"
            required
          />
        </div>
        <div v-if="error" class="alert alert-danger py-2 small" role="alert">{{ error }}</div>
        <button class="btn btn-accent w-100" :disabled="busy">
          {{ busy ? '请稍候…' : isRegister ? '注册并进入' : '登录' }}
        </button>
      </form>

      <div class="auth-switch">
        <template v-if="isRegister">已有账号？<router-link to="/login">去登录</router-link></template>
        <template v-else>还没有账号？<router-link to="/register">立即注册</router-link></template>
      </div>
    </div>
  </div>
</template>
