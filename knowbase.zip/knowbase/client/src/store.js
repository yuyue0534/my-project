import { reactive, computed } from 'vue'
import { api, getToken, setToken } from './api'

const EXPANDED_KEY = 'kb_expanded'
const LAST_PAGE_KEY = 'kb_last_page'

function loadExpanded() {
  try {
    return JSON.parse(localStorage.getItem(EXPANDED_KEY) || '[]')
  } catch {
    return []
  }
}

// 当前页面注册的"立即保存"函数；退出登录前先调用，避免丢失未保存的修改
export const hooks = { flush: null }

export const store = reactive({
  user: null,
  authChecked: false,
  pages: [], // 扁平列表，树结构由 tree 计算得出
  pagesLoaded: false,
  expanded: loadExpanded(),
  saveStatus: 'idle', // idle | dirty | saving | saved | error
  dragId: null // 正在拖动的侧边栏页面
})

/* ---------- 认证 ---------- */
export async function initAuth() {
  if (getToken()) {
    try {
      store.user = (await api.me()).user
    } catch {
      setToken(null)
      store.user = null
    }
  }
  store.authChecked = true
}

export async function login(email, password) {
  const r = await api.login(email, password)
  setToken(r.token)
  store.user = r.user
}

export async function register(email, password, name) {
  const r = await api.register(email, password, name)
  setToken(r.token)
  store.user = r.user
}

export function resetSession() {
  store.user = null
  store.pages = []
  store.pagesLoaded = false
  store.saveStatus = 'idle'
}

export async function logout() {
  try {
    await hooks.flush?.()
  } catch {
    /* 忽略 */
  }
  try {
    await api.logout()
  } catch {
    /* 忽略 */
  }
  setToken(null)
  resetSession()
}

/* ---------- 页面树 ---------- */
export async function loadPages() {
  store.pages = (await api.listPages()).pages
  store.pagesLoaded = true
}

export const tree = computed(() => {
  const byParent = new Map()
  for (const p of store.pages) {
    const key = p.parent_id || 'root'
    if (!byParent.has(key)) byParent.set(key, [])
    byParent.get(key).push(p)
  }
  const build = (key) =>
    (byParent.get(key) || [])
      .slice()
      .sort((a, b) => a.position - b.position)
      .map((p) => ({ ...p, children: build(p.id) }))
  return build('root')
})

export const getPage = (id) => store.pages.find((p) => p.id === id)

export function ancestorsOf(id) {
  const chain = []
  let cur = getPage(id)
  while (cur && chain.length < 100) {
    chain.unshift(cur)
    cur = cur.parent_id ? getPage(cur.parent_id) : null
  }
  return chain
}

export function isDescendant(id, ancestorId) {
  let cur = getPage(id)
  for (let i = 0; cur && i < 100; i++) {
    if (cur.id === ancestorId) return true
    cur = cur.parent_id ? getPage(cur.parent_id) : null
  }
  return false
}

export async function createPage(parentId = null) {
  const { page } = await api.createPage(parentId, '')
  store.pages.push(page)
  if (parentId) expand(parentId)
  return page
}

export async function removePage(id) {
  const { deleted } = await api.deletePage(id)
  const gone = new Set(deleted)
  store.pages = store.pages.filter((p) => !gone.has(p.id))
  return gone
}

export async function movePage(id, targetId, position) {
  await api.movePage(id, targetId, position)
  if (position === 'inside' && targetId) expand(targetId)
  await loadPages()
}

export function patchPage(id, patch) {
  const p = getPage(id)
  if (p) Object.assign(p, patch)
}

/* ---------- 展开状态 ---------- */
function saveExpanded() {
  localStorage.setItem(EXPANDED_KEY, JSON.stringify(store.expanded))
}
export const isExpanded = (id) => store.expanded.includes(id)
export function expand(id) {
  if (!isExpanded(id)) {
    store.expanded.push(id)
    saveExpanded()
  }
}
export function toggleExpand(id) {
  const i = store.expanded.indexOf(id)
  if (i >= 0) store.expanded.splice(i, 1)
  else store.expanded.push(id)
  saveExpanded()
}
export function expandAncestors(id) {
  ancestorsOf(id)
    .slice(0, -1)
    .forEach((p) => expand(p.id))
}

/* ---------- 最近访问 ---------- */
export const rememberPage = (id) => localStorage.setItem(LAST_PAGE_KEY, id)
export const lastPageId = () => localStorage.getItem(LAST_PAGE_KEY)
