# Knowbase · 类 Notion 知识库（第一阶段骨架）

**Vue 3 (JavaScript) + Bootstrap 5 + SQLite**，单进程、本地存储、开箱即用。

已实现：注册登录 · 页面树（嵌套 / 拖拽排序 / 展开收起）· 块编辑器 · 自动保存 · 全文搜索（中英文）

## 快速开始

需要 Node.js ≥ 22（LTS 即可）。依赖 `better-sqlite3` 已内置预编译二进制，无需 C++ 编译环境（项目 `.npmrc` 已设置 `ignore-scripts=true`，请保留）。

```bash
npm install
npm start
# 打开 http://localhost:3000，注册一个账号即可（会自动生成示例页面）
```

> 压缩包内已包含构建好的前端（`dist/`），所以不需要先 build。
> 数据保存在 `data/knowbase.db`（SQLite 文件），删除它即可重置全部数据。

可选环境变量：`PORT`（默认 3000）、`HOST`（默认 127.0.0.1，局域网访问用 `HOST=0.0.0.0`）、`DATA_DIR`（数据目录）。

## 开发模式

```bash
npm run dev      # 同时启动后端(3000, 自动重启) 和 Vite(5173, 热更新)；浏览器打开 http://localhost:5173
npm run build    # 修改前端后重新构建 dist/
```

## 编辑器操作

| 操作 | 效果 |
|---|---|
| 空行输入 `/` | 弹出块类型菜单（↑↓ 选择，Enter / Tab 确认，Esc 关闭，可输入 `todo`、`h1`、`代码` 等过滤） |
| `# ` `## ` `### ` | 标题 1/2/3 |
| `- ` `* ` | 无序列表 ； `1. ` 有序列表（自动编号） |
| `[] ` / `[x] ` | 待办（未完成 / 已完成） |
| `> ` | 引用 ； ` ``` ` 代码块 ； `---` 分割线 |
| Enter | 拆分块（列表/待办会延续类型；空列表项再按 Enter 退出列表） |
| Shift+Enter | 块内换行（代码块内 Enter 即换行，Shift/Ctrl+Enter 跳出代码块） |
| Backspace（行首） | 先把特殊块还原为段落，再合并到上一块 |
| Ctrl/⌘ + Shift + ↑/↓ | 上下移动当前块 |
| 悬停块左侧 `+` | 在下方插入块并打开菜单 |
| 拖动 / 点击左侧 `⋮⋮` | 拖拽排序 / 转换类型、复制、删除 |
| Ctrl/⌘ + K | 全文搜索 |

页面树：悬停页面可「添加子页面」或「删除」；拖到页面上半/下半 = 排在其前/后，拖到中间 = 变成其子页面；拖拽时底部出现"移到顶层"区域。

## 目录结构

```
server/
  index.js            Express 入口（API + 托管 dist/，SPA 回退）
  db.js               SQLite 建表、FTS5 全文索引
  auth.js             scrypt 密码哈希、会话 token、requireAuth 中间件
  util.js             块数据校验清洗、纯文本抽取、搜索摘要
  welcome.js          新用户示例页面
  routes/             auth.js · pages.js · search.js
client/
  index.html
  src/
    main.js  router.js  store.js  api.js  blocks.js  autosize.js  styles.css
    views/            AuthView · WorkspaceView · HomeView · PageView
    components/       PageTree · PageTreeItem · BlockEditor · BlockRow · SearchModal
vite.config.js        root=client，输出到 dist/，dev 时代理 /api
```

## API

所有接口（除注册/登录）需要 `Authorization: Bearer <token>`。

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/auth/register` `/login` `/logout` | `{email,password,name?}` → `{token,user}` |
| GET | `/api/auth/me` | 当前用户 |
| GET | `/api/pages` | 页面树（扁平列表，不含正文） |
| POST | `/api/pages` | `{parent_id?, title?}` 新建 |
| GET / PUT / DELETE | `/api/pages/:id` | 读取（含正文）/ 更新 `{title?,icon?,content?}` / 递归删除 |
| PATCH | `/api/pages/:id/move` | `{target_id, position: before\|after\|inside\|root}` |
| GET | `/api/search?q=` | 全文搜索，返回命中摘要 |

## 关键设计说明

- **数据模型**：页面是树（`pages.parent_id` + `position`）；页面正文是块数组 JSON：`[{ id, type, text, checked? }]`，类型有 `paragraph h1 h2 h3 todo bullet numbered quote code divider`。第一阶段把正文整体存在页面行里，简单可靠；当需要块级协同或数据库视图时，再把块拆成独立表（见下）。
- **全文搜索**：SQLite **FTS5 + trigram 分词器**，对中文无需分词库即可做子串匹配；trigram 要求关键词 ≥ 3 个字符，更短的词（如 2 个汉字）自动回退到 `LIKE`。多个关键词用空格分隔，需同时命中。若 SQLite 版本不支持 trigram，则全部降级为 `LIKE`。
- **编辑器**：每个块一个自适应高度的 `<textarea>`，输入法、撤销、光标全部由浏览器原生处理，稳定性优先。代价是暂不支持行内富文本（加粗/链接）和跨块选择。
- **自动保存**：停止输入 0.8 秒后保存；切换页面、退出登录、关闭标签页时会立即保存；失败会自动重试。
- **安全**：密码用 scrypt + 随机盐；会话 token 存于 SQLite，30 天过期；所有页面接口按 `user_id` 隔离。**尚未做**登录限流、CSRF/HTTPS 等，部署到公网前需要补上。

## 下一步建议

1. **富文本**：把 `BlockRow` 内部的 textarea 换成 Tiptap/ProseMirror 的行内编辑（加粗、斜体、链接、`@` 页面提及），块菜单与数据流可保留。
2. **图片 / 文件块**：增加上传接口（本地目录或 S3），新增 `image` 块类型。
3. **回收站与版本历史**：`pages` 加 `deleted_at` 软删除；保存时写入 `page_versions` 快照。
4. **反向链接**：解析页面提及，新建 `links(from_page, to_page)` 表。
5. **协同**：引入 Yjs + Hocuspocus，正文改为 Y.Doc；此时再把块拆表。
6. **数据库视图**：在块类型中加入 `database`，行 = 子页面，属性存 JSONB 式 JSON 列。
