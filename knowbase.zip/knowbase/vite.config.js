import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// 前端源码在 client/，构建产物输出到 dist/，由 Express 直接托管
export default defineConfig({
  root: 'client',
  plugins: [vue()],
  build: { outDir: '../dist', emptyOutDir: true },
  server: {
    port: 5173,
    proxy: { '/api': 'http://127.0.0.1:3000' }
  }
})
