-- NoteSpace v1.0; paste everything into Supabase SQL Editor, run once on a new project.
create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(btrim(name)) between 1 and 120),
  owner_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  created_at timestamptz not null default now()
);
create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'viewer' check (role in ('owner','admin','editor','viewer')),
  primary key (workspace_id,user_id)
);
create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  parent_id uuid references public.pages(id) on delete cascade,
  title text not null default '无标题' check (char_length(title) between 1 and 120),
  icon text not null default '📄' check (char_length(icon) <= 40),
  sort_order bigint not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (id is distinct from parent_id)
);
create index if not exists ix_pages_work_parent_order on public.pages(workspace_id,parent_id,sort_order,id);
create index if not exists ix_pages_parent_id on public.pages(parent_id);
create index if not exists ix_workspace_members_user on public.workspace_members(user_id,workspace_id);

-- SECURITY DEFINER helpers avoid recursive membership-policy lookups.
create or replace function public.is_workspace_member(p_workspace_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.workspace_members wm where wm.workspace_id=p_workspace_id and wm.user_id=(select auth.uid()));
$$;
create or replace function public.can_edit_workspace(p_workspace_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.workspace_members wm where wm.workspace_id=p_workspace_id and wm.user_id=(select auth.uid()) and wm.role in ('owner','admin','editor'));
$$;
revoke all on function public.is_workspace_member(uuid) from public;
revoke all on function public.can_edit_workspace(uuid) from public;
grant execute on function public.is_workspace_member(uuid) to authenticated;
grant execute on function public.can_edit_workspace(uuid) to authenticated;

create or replace function public.add_workspace_owner() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.owner_id is distinct from auth.uid() then raise exception 'Invalid workspace owner'; end if;
  insert into public.workspace_members(workspace_id,user_id,role) values(new.id,new.owner_id,'owner');
  return new;
end $$;
drop trigger if exists tg_workspace_owner on public.workspaces;
create trigger tg_workspace_owner after insert on public.workspaces for each row execute function public.add_workspace_owner();

create or replace function public.touch_page() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at=now(); return new; end $$;
drop trigger if exists tg_page_updated on public.pages;
create trigger tg_page_updated before update on public.pages for each row execute function public.touch_page();

-- Every direct parent update must remain in the same workspace and be acyclic.
create or replace function public.validate_page_parent() returns trigger
language plpgsql security definer set search_path = '' as $$
declare parent_workspace uuid; found_cycle boolean;
begin
  if new.parent_id is null then return new; end if;
  select workspace_id into parent_workspace from public.pages where id=new.parent_id;
  if parent_workspace is distinct from new.workspace_id then raise exception 'Parent must be in same workspace'; end if;
  if new.id is not null and new.id=new.parent_id then raise exception 'Cannot parent page to itself'; end if;
  with recursive lineage as (
    select id,parent_id, array[id] as visited from public.pages where id=new.parent_id
    union all
    select p.id,p.parent_id,l.visited||p.id from public.pages p join lineage l on p.id=l.parent_id
    where not p.id=any(l.visited)
  ) select exists(select 1 from lineage where id=new.id) into found_cycle;
  if found_cycle then raise exception 'Cannot move a page into its descendant'; end if;
  return new;
end $$;
drop trigger if exists tg_page_parent on public.pages;
create trigger tg_page_parent before insert or update of parent_id,workspace_id on public.pages
for each row execute function public.validate_page_parent();

alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.pages enable row level security;
drop policy if exists ws_select on public.workspaces;
create policy ws_select on public.workspaces for select to authenticated using (public.is_workspace_member(id));
drop policy if exists ws_insert on public.workspaces;
create policy ws_insert on public.workspaces for insert to authenticated with check (owner_id=(select auth.uid()));
drop policy if exists ws_update on public.workspaces;
create policy ws_update on public.workspaces for update to authenticated using (owner_id=(select auth.uid())) with check (owner_id=(select auth.uid()));
drop policy if exists ws_delete on public.workspaces;
create policy ws_delete on public.workspaces for delete to authenticated using (owner_id=(select auth.uid()));
drop policy if exists members_select on public.workspace_members;
create policy members_select on public.workspace_members for select to authenticated using (public.is_workspace_member(workspace_id));
-- V1 intentionally disallows direct membership editing; an admin-controlled invitation flow comes later.
drop policy if exists pages_select on public.pages;
create policy pages_select on public.pages for select to authenticated using (public.is_workspace_member(workspace_id));
drop policy if exists pages_insert on public.pages;
create policy pages_insert on public.pages for insert to authenticated with check (public.can_edit_workspace(workspace_id));
drop policy if exists pages_update on public.pages;
create policy pages_update on public.pages for update to authenticated using (public.can_edit_workspace(workspace_id)) with check (public.can_edit_workspace(workspace_id));
drop policy if exists pages_delete on public.pages;
create policy pages_delete on public.pages for delete to authenticated using (public.can_edit_workspace(workspace_id));

-- Only RPC can create/move for well-defined sibling positions.
create or replace function public.create_page(p_workspace_id uuid,p_parent_id uuid default null,p_title text default '无标题')
returns uuid language plpgsql security invoker set search_path = '' as $$
declare new_id uuid; next_order bigint;
begin
  if not public.can_edit_workspace(p_workspace_id) then raise exception 'Not permitted'; end if;
  perform pg_advisory_xact_lock(hashtextextended(p_workspace_id::text,0));
  if p_parent_id is not null and not exists(select 1 from public.pages where id=p_parent_id and workspace_id=p_workspace_id) then
    raise exception 'Invalid parent page';
  end if;
  select coalesce(max(sort_order),0)+1024 into next_order from public.pages
  where workspace_id=p_workspace_id and parent_id is not distinct from p_parent_id;
  insert into public.pages(workspace_id,parent_id,title,sort_order)
  values(p_workspace_id,p_parent_id,coalesce(nullif(btrim(p_title),''),'无标题'),next_order)
  returning id into new_id;
  return new_id;
end $$;

create or replace function public.move_page(p_page_id uuid,p_target_page_id uuid,p_placement text)
returns void language plpgsql security invoker set search_path = '' as $$
declare source_workspace uuid; target_workspace uuid; source_parent uuid; destination_parent uuid;
declare ids uuid[]; positioned uuid[] := '{}'::uuid[]; el uuid; idx integer; pos integer; i integer;
begin
  if p_placement not in ('before','after','inside') then raise exception 'Invalid placement'; end if;
  if p_page_id=p_target_page_id then raise exception 'Cannot move onto itself'; end if;
  select workspace_id,parent_id into source_workspace,source_parent from public.pages where id=p_page_id;
  if source_workspace is null or not public.can_edit_workspace(source_workspace) then raise exception 'Not permitted'; end if;
  perform pg_advisory_xact_lock(hashtextextended(source_workspace::text,0));
  select workspace_id into target_workspace from public.pages where id=p_target_page_id;
  if target_workspace is distinct from source_workspace then raise exception 'Pages must share a workspace'; end if;
  if p_placement='inside' then destination_parent:=p_target_page_id;
  else select parent_id into destination_parent from public.pages where id=p_target_page_id; end if;
  -- A recursive ancestor walk rejects self-parenting and descendant cycles.
  if destination_parent is not null then
    if exists (
      with recursive ancestors as (
        select id,parent_id,array[id] as visited from public.pages where id=destination_parent
        union all
        select p.id,p.parent_id,a.visited||p.id from public.pages p join ancestors a on p.id=a.parent_id
        where not p.id=any(a.visited)
      ) select 1 from ancestors where id=p_page_id
    ) then raise exception 'Cannot move a page into itself or descendants'; end if;
  end if;
  update public.pages set parent_id=destination_parent where id=p_page_id;
  select coalesce(array_agg(id order by sort_order,created_at,id),'{}'::uuid[]) into ids
  from public.pages where workspace_id=source_workspace and parent_id is not distinct from destination_parent and id<>p_page_id;
  if p_placement='inside' then positioned:=ids||p_page_id;
  else
    pos:=array_position(ids,p_target_page_id);
    if pos is null then raise exception 'Target is not a sibling'; end if;
    for i in 1..coalesce(array_length(ids,1),0) loop
      if i=pos and p_placement='before' then positioned:=array_append(positioned,p_page_id); end if;
      positioned:=array_append(positioned,ids[i]);
      if i=pos and p_placement='after' then positioned:=array_append(positioned,p_page_id); end if;
    end loop;
  end if;
  for i in 1..coalesce(array_length(positioned,1),0) loop
    update public.pages set sort_order=i*1024 where id=positioned[i];
  end loop;
  if source_parent is distinct from destination_parent then
    -- Compact the old sibling sequence too.
    with ordered as (
      select id,row_number() over(order by sort_order,created_at,id)*1024 as n
      from public.pages where workspace_id=source_workspace and parent_id is not distinct from source_parent
    ) update public.pages p set sort_order=ordered.n from ordered where p.id=ordered.id;
  end if;
end $$;
revoke all on function public.create_page(uuid,uuid,text) from public;
revoke all on function public.move_page(uuid,uuid,text) from public;
grant execute on function public.create_page(uuid,uuid,text) to authenticated;
grant execute on function public.move_page(uuid,uuid,text) to authenticated;
