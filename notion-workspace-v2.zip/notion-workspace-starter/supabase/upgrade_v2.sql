-- NoteSpace v2 incremental migration. Run AFTER schema.sql. Idempotent on repeated execution.
alter table public.pages add column if not exists content jsonb not null default '{"type":"doc","content":[{"type":"paragraph"}]}'::jsonb;
alter table public.pages add column if not exists content_version bigint not null default 0;
alter table public.pages add column if not exists deleted_at timestamptz;
create index if not exists ix_pages_workspace_deleted on public.pages(workspace_id,deleted_at);

create or replace function public.save_page_content(p_page_id uuid,p_content jsonb,p_expected_version bigint)
returns bigint language plpgsql security invoker set search_path='' as $$
declare v bigint;
begin
 if p_content is null or p_content->>'type' is distinct from 'doc' or jsonb_typeof(p_content->'content') <> 'array' then raise exception 'Invalid document JSON'; end if;
 if pg_column_size(p_content)>2000000 then raise exception 'Document too large'; end if;
 update public.pages set content=p_content,content_version=content_version+1
 where id=p_page_id and deleted_at is null and content_version=p_expected_version
 returning content_version into v;
 if v is null then raise exception 'content_conflict: no write permission or newer content'; end if;
 return v;
end $$;
revoke all on function public.save_page_content(uuid,jsonb,bigint) from public;
grant execute on function public.save_page_content(uuid,jsonb,bigint) to authenticated;

-- Lock workspace while updating the entire page subtree to avoid interleaving delete/restore.
create or replace function public.trash_page(p_page_id uuid)
returns void language plpgsql security invoker set search_path='' as $$
declare wid uuid;
begin
 select workspace_id into wid from public.pages where id=p_page_id and deleted_at is null;
 if wid is null or not public.can_edit_workspace(wid) then raise exception 'Not permitted';end if;
 perform pg_advisory_xact_lock(hashtextextended(wid::text,0));
 with recursive subtree as (
  select id from public.pages where id=p_page_id
  union all select p.id from public.pages p join subtree s on p.parent_id=s.id
 ) update public.pages set deleted_at=now() where id in (select id from subtree) and deleted_at is null;
end $$;
create or replace function public.restore_page(p_page_id uuid)
returns void language plpgsql security invoker set search_path='' as $$
declare wid uuid; pid uuid;
begin
 select workspace_id,parent_id into wid,pid from public.pages where id=p_page_id and deleted_at is not null;
 if wid is null or not public.can_edit_workspace(wid) then raise exception 'Not permitted'; end if;
 perform pg_advisory_xact_lock(hashtextextended(wid::text,0));
 -- Root restored as top-level if parent is still in trash.
 if pid is not null and exists(select 1 from public.pages where id=pid and deleted_at is not null) then
  update public.pages set parent_id=null where id=p_page_id;
 end if;
 with recursive subtree as (
  select id from public.pages where id=p_page_id
  union all select p.id from public.pages p join subtree s on p.parent_id=s.id
 ) update public.pages set deleted_at=null where id in(select id from subtree);
end $$;
create or replace function public.purge_page(p_page_id uuid)
returns void language plpgsql security invoker set search_path='' as $$
declare wid uuid;
begin
 select workspace_id into wid from public.pages where id=p_page_id and deleted_at is not null;
 if wid is null or not public.can_edit_workspace(wid) then raise exception 'Not permitted';end if;
 perform pg_advisory_xact_lock(hashtextextended(wid::text,0));
 -- Page CASCADE removes its child subtree only after explicit trashing.
 delete from public.pages where id=p_page_id and deleted_at is not null;
end $$;
revoke all on function public.trash_page(uuid) from public;
revoke all on function public.restore_page(uuid) from public;
revoke all on function public.purge_page(uuid) from public;
grant execute on function public.trash_page(uuid),public.restore_page(uuid),public.purge_page(uuid) to authenticated;

create table if not exists public.workspace_invitations(
 id uuid primary key default gen_random_uuid(),
 workspace_id uuid not null references public.workspaces(id) on delete cascade,
 email text not null,
 role text not null check(role in ('editor','viewer')),
 status text not null default 'pending' check(status in ('pending','accepted','revoked')),
 invited_by uuid not null references auth.users(id),
 created_at timestamptz not null default now(),
 accepted_at timestamptz
);
create unique index if not exists unique_pending_ws_invite on public.workspace_invitations(workspace_id,lower(email)) where status='pending';
create index if not exists ix_workspace_invitations_email on public.workspace_invitations(lower(email),status);
alter table public.workspace_invitations enable row level security;
drop policy if exists invitations_select on public.workspace_invitations;
create policy invitations_select on public.workspace_invitations for select to authenticated
 using(exists(select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()));

create or replace function public.create_workspace_invite(p_workspace_id uuid,p_email text,p_role text default 'editor')
returns uuid language plpgsql security definer set search_path='' as $$
declare inv_id uuid; normalized text;
begin
 if not exists(select 1 from public.workspaces where id=p_workspace_id and owner_id=auth.uid()) then raise exception 'Only workspace owner can invite';end if;
 normalized:=lower(btrim(p_email));
 if normalized !~ '^[^ @]+@[^ @]+\.[^ @]+$' then raise exception 'Invalid email';end if;
 if p_role not in ('editor','viewer') then raise exception 'Invalid role';end if;
 insert into public.workspace_invitations(workspace_id,email,role,invited_by)
 values(p_workspace_id,normalized,p_role,auth.uid())
 on conflict (workspace_id,lower(email)) where status='pending' do update set role=excluded.role
 returning id into inv_id;
 return inv_id;
end $$;
create or replace function public.accept_my_invites()
returns integer language plpgsql security definer set search_path='' as $$
declare email_value text; invite_row record; n integer:=0;
begin
 if auth.uid() is null then raise exception 'Not authenticated';end if;
 select lower(email) into email_value from auth.users where id=auth.uid() and email_confirmed_at is not null;
 if email_value is null then raise exception 'Verify your email address to accept invitations'; end if;
 for invite_row in select * from public.workspace_invitations where lower(email)=email_value and status='pending' for update loop
   insert into public.workspace_members(workspace_id,user_id,role)
   values(invite_row.workspace_id,auth.uid(),invite_row.role)
   on conflict(workspace_id,user_id) do nothing;
   update public.workspace_invitations set status='accepted',accepted_at=now() where id=invite_row.id;
   n:=n+1;
 end loop;
 return n;
end $$;
revoke all on function public.create_workspace_invite(uuid,text,text), public.accept_my_invites() from public;
grant execute on function public.create_workspace_invite(uuid,text,text), public.accept_my_invites() to authenticated;

-- Enable filtered Postgres changes after table exists; dashboard must enable Realtime in some hosted setups.
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='pages') then
   alter publication supabase_realtime add table public.pages;
 end if;
end $$;
