<script setup>
import { computed, ref, watch } from 'vue'
import { BookOpen, Search, Plus, ChevronsUpDown, PanelLeftClose, PanelLeftOpen, LogOut, FileText, House, MoreHorizontal, Pencil, FolderPlus, RefreshCw } from 'lucide-vue-next'
import PageTreeNode from '../components/PageTreeNode.vue'
import BlockEditor from '../components/BlockEditor.vue'
import { supabase } from '../lib/supabase'
import { onMounted, onBeforeUnmount } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useWorkspaceStore } from '../stores/workspace'
import { explainError } from '../lib/supabase'
const auth = useAuthStore(), store = useWorkspaceStore()
const activeId = ref(''), expanded = ref({}), draggingId = ref(''), sidebarVisible = ref(true), workspaceMenu = ref(false)
const section = ref('pages'), inviteEmail=ref(''), inviteRole=ref('editor'), invitations=ref([]), memberBusy=ref(false)
const dialog = ref(null), value = ref(''), pending = ref(false), notice = ref(''), search = ref(''), searchOpen = ref(false)
const activePage = computed(() => store.pageMap.get(activeId.value))
const canEdit = computed(() => store.current?.owner_id === auth.user?.id || currentRole.value === 'editor' || currentRole.value === 'admin')
// workspace_members 的角色供 UI 使用；实际权限由 Supabase RLS 决定。
const currentRole = ref('viewer')
async function getRole(){
  currentRole.value = 'viewer'
  if (!store.currentId) return
  const { supabase } = await import('../lib/supabase')
  const { data, error } = await supabase.from('workspace_members').select('role').eq('workspace_id', store.currentId).eq('user_id', auth.user.id).maybeSingle()
  if (!error && data) currentRole.value = data.role
}
watch(() => store.currentId, async () => { activeId.value = ''; section.value='pages'; await getRole(); if(store.currentId) await loadTeam() }, { immediate: true })
let channel=null
watch(()=>store.currentId,(id)=>{
 if(channel){supabase.removeChannel(channel);channel=null}
 if(id){channel=supabase.channel('workspace-'+id).on('postgres_changes',{event:'*',schema:'public',table:'pages',filter:`workspace_id=eq.${id}`},()=>store.loadPages().catch(console.error)).subscribe()}
},{immediate:true})
onBeforeUnmount(()=>{if(channel)supabase.removeChannel(channel)})
async function loadTeam(){try{await store.loadMembers();invitations.value=store.current?.owner_id===auth.user?.id?await store.loadInvites():[]}catch(e){notice.value=explainError(e)}}
async function sendInvite(){if(!inviteEmail.value.trim())return;memberBusy.value=true;try{await store.invite(inviteEmail.value,inviteRole.value);inviteEmail.value='';await loadTeam();notice.value='邀请记录已创建。请将登录地址发送给对方，对方邮箱验证后在页面点击「接受邀请」。'}catch(e){notice.value=explainError(e)}finally{memberBusy.value=false}}
async function acceptInvites(){await run(async()=>{await store.acceptInvites();await getRole();await loadTeam()})}
async function openTrash(){section.value='trash';await run(()=>store.loadTrash())}
async function restore(id){await run(()=>store.restorePage(id))}
async function purge(id){if(!confirm('永久删除这条页面及子页面？不可撤销。'))return;await run(()=>store.purgePage(id))}
const matches = computed(() => store.pages.filter(p => (p.title||'').toLowerCase().includes(search.value.trim().toLowerCase())).slice(0,30))
const breadcrumb = computed(() => {
  const list=[];let current=activePage.value;const visited=new Set()
  while(current && !visited.has(current.id)) { list.unshift(current);visited.add(current.id);current=store.pageMap.get(current.parent_id) }
  return list
})
function showDialog(type, id = null) {
  const node = store.pageMap.get(id)
  value.value = type === 'rename' ? node?.title || '' : type === 'rename-workspace' ? store.current?.name || '' : ''
  dialog.value = { type, id }
}
async function run(action){try{notice.value='';await action()}catch(e){notice.value=explainError(e);console.error(e)}}
async function submitDialog(){
  if (!dialog.value || !value.value.trim()) return
  pending.value=true
  const d=dialog.value
  try {
    if (d.type==='workspace') await store.createWorkspace(value.value)
    if (d.type==='rename-workspace') await store.renameWorkspace(store.currentId,value.value)
    if (d.type==='rename') await store.updatePage(d.id,{title:value.value.trim()})
    dialog.value=null
  }catch(e){notice.value=explainError(e)}finally{pending.value=false}
}
async function addPage(parentId=null){await run(async()=>{const id=await store.createPage(parentId);if(parentId)expanded.value[parentId]=true;activeId.value=id;showDialog('rename',id)})}
async function deletePage(id){
  const page=store.pageMap.get(id)
  if(!confirm(`确定删除「${page?.title||'无标题'}」及其所有子页面吗？可在回收站恢复。`)) return
  await run(async()=>{await store.deletePage(id);if(!store.pageMap.has(activeId.value))activeId.value='';})
}
async function movePage(id,target,placement){await run(async()=>{await store.movePage(id,target,placement);if(placement==='inside')expanded.value[target]=true})}
function selectPage(id){section.value='pages';activeId.value=id;searchOpen.value=false;search.value=''}
async function logout(){await run(()=>auth.signOut())}
const initials = computed(()=>auth.user?.email?.[0]?.toUpperCase()||'U')
</script>
<template>
<div class="flex h-screen overflow-hidden bg-white">
  <aside v-if="sidebarVisible" class="w-[272px] max-w-[85vw] bg-[#f7f7f5] border-r border-zinc-200/70 flex flex-col shrink-0">
    <div class="p-2.5 relative"><button class="w-full flex items-center gap-2 rounded-lg hover:bg-zinc-200/70 px-2 py-2 text-left" @click="workspaceMenu=!workspaceMenu"><span class="w-7 h-7 rounded-md bg-zinc-800 text-white grid place-items-center text-sm font-semibold">{{(store.current?.name||'N').slice(0,1).toUpperCase()}}</span><span class="flex-1 truncate text-sm font-semibold">{{store.current?.name||'选择工作区'}}</span><ChevronsUpDown :size="15" class="text-zinc-400" /></button>
      <div v-if="workspaceMenu" class="absolute z-40 left-3 right-3 top-14 bg-white border shadow-xl rounded-xl p-2 text-sm"><p class="px-2 pb-2 text-xs text-zinc-400">我的工作区</p><button v-for="item in store.workspaces" :key="item.id" class="block w-full text-left px-3 py-2 hover:bg-zinc-100 rounded-md truncate" @click="run(()=>store.chooseWorkspace(item.id));workspaceMenu=false">{{item.name}} <span v-if="item.id===store.currentId" class="text-blue-600">✓</span></button><hr class="my-1"/><button class="w-full text-left px-3 py-2 hover:bg-zinc-100 rounded-md" @click="showDialog('workspace');workspaceMenu=false">＋ 新建 Workspace</button><button v-if="store.current?.owner_id===auth.user.id" class="w-full text-left px-3 py-2 hover:bg-zinc-100 rounded-md" @click="showDialog('rename-workspace');workspaceMenu=false">✎ 重命名工作区</button></div>
    </div>
    <div class="px-2 space-y-0.5"><button class="flex items-center gap-2 w-full px-3 py-2 text-[13px] rounded-md hover:bg-zinc-200/70 text-zinc-600" @click="searchOpen=true;search=''"><Search :size="17"/> 搜索</button><button class="flex items-center gap-2 w-full px-3 py-2 text-[13px] rounded-md hover:bg-zinc-200/70 text-zinc-600" @click="activeId='';section='pages' "><House :size="17"/> 主页</button><button class="flex items-center gap-2 w-full px-3 py-2 text-[13px] rounded-md hover:bg-zinc-200/70 text-zinc-600" @click="openTrash">♻ 回收站</button><button class="flex items-center gap-2 w-full px-3 py-2 text-[13px] rounded-md hover:bg-zinc-200/70 text-zinc-600" @click="section='members';loadTeam()">♧ 成员与邀请</button></div>
    <div class="flex items-center justify-between px-4 mt-7 mb-2 text-xs font-semibold text-zinc-400"><span>私有与共享页面</span><button v-if="canEdit" title="新建顶层页面" class="p-1 rounded hover:bg-zinc-200" @click="addPage(null)"><Plus :size="16"/></button></div>
    <div class="flex-1 min-h-0 overflow-auto scrollbar-thin px-1" @dragover.prevent @drop.prevent>
      <PageTreeNode v-for="node in store.tree" :key="node.id" :node="node" :expanded="expanded" :active-id="activeId" :can-edit="canEdit" :dragging-id="draggingId" @select="selectPage" @toggle="id=>expanded[id]=expanded[id]===false?true:false" @add="addPage" @rename="id=>showDialog('rename',id)" @remove="deletePage" @move="movePage" @dragging="id=>draggingId=id" />
      <button v-if="canEdit" class="mt-2 w-full flex gap-2 items-center px-3 py-2 text-zinc-400 hover:text-zinc-700 hover:bg-zinc-200/70 rounded-md text-[13px]" @click="addPage(null)"><Plus :size="16"/> 新建页面</button>
      <p v-if="!store.pages.length" class="text-xs text-zinc-400 px-4 mt-3">暂无页面，点击 + 开始。</p>
    </div>
    <div class="border-t p-3 flex gap-2 items-center"><div class="h-8 w-8 rounded-full bg-orange-100 text-orange-700 grid place-items-center text-sm font-bold">{{initials}}</div><span class="flex-1 text-xs text-zinc-600 truncate">{{auth.user?.email}}</span><button title="退出登录" class="text-zinc-400 hover:text-red-600" @click="logout"><LogOut :size="17"/></button></div>
  </aside>
  <main class="min-w-0 flex-1 flex flex-col"><div class="h-12 border-b border-zinc-100 flex items-center gap-2 px-4 text-sm text-zinc-500"><button class="p-1 hover:bg-zinc-100 rounded-md" :title="sidebarVisible?'收起侧边栏':'展开侧边栏'" @click="sidebarVisible=!sidebarVisible"><PanelLeftClose v-if="sidebarVisible" :size="18"/><PanelLeftOpen v-else :size="18"/></button><span class="text-zinc-300">/</span><button class="truncate hover:text-zinc-900" @click="activeId=''">{{store.current?.name||'NoteSpace'}}</button><template v-for="crumb in breadcrumb" :key="crumb.id"><span class="text-zinc-300">/</span><button class="truncate max-w-44 hover:text-zinc-900" @click="selectPage(crumb.id)">{{crumb.icon||'📄'}} {{crumb.title}}</button></template><span class="flex-1"/><button title="刷新页面树" @click="run(()=>store.loadPages())" class="p-1.5 rounded hover:bg-zinc-100"><RefreshCw :size="15"/></button></div>
    <div v-if="notice" role="alert" class="bg-red-50 text-red-700 text-sm px-5 py-2 flex justify-between"><span>{{notice}}</span><button @click="notice=''">✕</button></div>
    <div class="overflow-auto flex-1"><div v-if="section==='trash' && store.current" class="max-w-3xl mx-auto px-8 pt-16"><h1 class="text-3xl font-bold">回收站</h1><p class="text-zinc-500 text-sm mt-2 mb-6">删除页面会将整个子树移入回收站，可恢复或永久删除。</p><div v-for="p in store.trash" :key="p.id" class="flex gap-3 items-center border-b py-3"><span>{{p.icon}}</span><span class="flex-1 truncate">{{p.title}}</span><button v-if="canEdit" class="text-blue-600 text-sm" @click="restore(p.id)">恢复</button><button v-if="canEdit" class="text-red-600 text-sm" @click="purge(p.id)">永久删除</button></div><p v-if="!store.trash.length" class="text-zinc-400 text-sm">回收站为空</p></div>
      <div v-else-if="section==='members' && store.current" class="max-w-3xl mx-auto px-8 pt-16"><h1 class="text-3xl font-bold">成员与邀请</h1><p class="mt-3 text-sm text-zinc-500">仅工作区 Owner 可创建邮箱邀请。此版本不会发送邮件，需要你自行分享应用地址。</p><div class="mt-8 border rounded-xl p-5"><h2 class="font-semibold mb-3">当前成员（{{store.members.length}}）</h2><div v-for="m in store.members" :key="m.user_id" class="flex justify-between text-sm py-2 border-b"><span class="text-zinc-500 truncate">{{m.user_id}}</span><span>{{m.role}}</span></div></div><form v-if="store.current.owner_id===auth.user?.id" class="mt-5 border rounded-xl p-5" @submit.prevent="sendInvite"><h2 class="font-semibold mb-3">邀请成员</h2><div class="flex flex-wrap gap-2"><input v-model="inviteEmail" required type="email" placeholder="成员邮箱" class="rounded border px-3 py-2 flex-1 min-w-[170px]"/><select v-model="inviteRole" class="rounded border px-3"><option value="editor">Editor</option><option value="viewer">Viewer</option></select><button :disabled="memberBusy" class="rounded bg-zinc-900 text-white px-4 py-2">创建邀请</button></div><div v-for="i in invitations" :key="i.id" class="flex gap-2 text-xs border-b py-2 mt-2"><span class="flex-1 truncate">{{i.email}}</span><span>{{i.role}}</span><span>{{i.status}}</span></div></form><button class="mt-5 px-4 py-2 border rounded-lg text-sm" @click="acceptInvites">接受发送至我的邮箱的邀请</button></div>
      <div v-else-if="!store.current" class="h-full grid place-items-center px-6"><div class="text-center max-w-md"><BookOpen :size="42" class="mx-auto text-zinc-300 mb-5"/><h1 class="text-2xl font-semibold">创建你的第一个工作空间</h1><p class="text-zinc-500 my-4">在这里整理文档、知识和项目，稍后还能继续扩展 Block 编辑器。</p><div class="flex justify-center gap-3 flex-wrap"><button class="bg-zinc-900 text-white rounded-lg px-5 py-2.5" @click="showDialog('workspace')">创建 Workspace</button><button class="border px-4 py-2 rounded-lg" @click="acceptInvites">接受工作区邀请</button></div></div></div>
      <div v-else-if="!activePage" class="max-w-3xl mx-auto px-8 pt-24"><div class="text-6xl mb-5">📚</div><h1 class="text-4xl font-bold tracking-tight">{{store.current.name}}</h1><p class="text-zinc-400 mt-5 mb-8">欢迎来到你的知识空间。选择左侧页面，或者开始创建新页面。</p><button v-if="canEdit" class="inline-flex items-center gap-2 text-sm bg-zinc-900 text-white px-4 py-2.5 rounded-lg hover:bg-zinc-700" @click="addPage(null)"><Plus :size="16"/> 创建新页面</button></div>
      <div v-else class="max-w-3xl mx-auto px-8 sm:px-12 pt-20 pb-24"><div class="text-7xl mb-7">{{activePage.icon||'📄'}}</div><div class="flex items-center gap-3"><h1 class="text-4xl font-bold tracking-tight break-all flex-1">{{activePage.title}}</h1><button v-if="canEdit" class="text-zinc-400 hover:text-zinc-800" title="重命名" @click="showDialog('rename',activePage.id)"><Pencil :size="18"/></button></div><div class="mt-6 flex gap-3 text-xs text-zinc-400"><span>创建于 {{new Date(activePage.created_at).toLocaleString('zh-CN')}}</span><span>·</span><span>最后更新 {{new Date(activePage.updated_at).toLocaleString('zh-CN')}}</span></div><BlockEditor :key="activePage.id" :page-id="activePage.id" :can-edit="canEdit"/><button v-if="canEdit" class="flex items-center gap-2 mt-8 text-zinc-500 text-sm hover:text-zinc-800" @click="addPage(activePage.id)"><FolderPlus :size="17"/> 在当前页面下创建子页面</button></div>
    </div>
  </main>
  <div v-if="dialog" class="fixed inset-0 z-50 bg-black/40 grid place-items-center p-4" @click.self="dialog=null"><form class="bg-white w-full max-w-md rounded-xl p-6 shadow-2xl" @submit.prevent="submitDialog"><h2 class="text-lg font-semibold mb-4">{{dialog.type==='workspace'?'新建工作区':dialog.type==='rename-workspace'?'重命名工作区':'重命名页面'}}</h2><input v-model="value" autofocus required maxlength="120" class="w-full rounded-lg border border-zinc-300 px-3 py-2.5 focus:border-blue-400 focus:ring-2 focus:ring-blue-100" :placeholder="dialog.type==='workspace'?'例如：我的知识库':'输入名称'"/><div class="mt-5 flex gap-2 justify-end"><button type="button" class="px-4 py-2 text-sm rounded-lg hover:bg-zinc-100" @click="dialog=null">取消</button><button :disabled="pending || !value.trim()" class="px-4 py-2 text-sm text-white rounded-lg bg-zinc-900 hover:bg-zinc-700">{{pending?'保存中…':'保存'}}</button></div></form></div>
  <div v-if="searchOpen" class="fixed inset-0 z-50 bg-black/40 flex justify-center items-start pt-[15vh] px-3" @click.self="searchOpen=false"><div class="bg-white w-full max-w-xl rounded-xl shadow-2xl overflow-hidden"><div class="flex items-center gap-3 p-4 border-b"><Search :size="19" class="text-zinc-400"/><input v-model="search" autofocus placeholder="搜索当前工作区中的页面标题…" class="flex-1 text-sm"/><button class="text-xs text-zinc-400" @click="searchOpen=false">ESC</button></div><div class="max-h-80 overflow-auto p-2"><button v-for="p in matches" :key="p.id" @click="selectPage(p.id)" class="w-full text-left px-3 py-2.5 hover:bg-zinc-100 rounded-md text-sm">{{p.icon||'📄'}} {{p.title}}</button><p v-if="!matches.length" class="text-center text-sm text-zinc-400 p-6">没有匹配的页面</p></div></div></div>
</div>
</template>
