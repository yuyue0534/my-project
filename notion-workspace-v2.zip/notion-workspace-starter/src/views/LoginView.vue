<script setup>
import { ref } from 'vue'
import { BookOpen, ArrowRight } from 'lucide-vue-next'
import { useAuthStore } from '../stores/auth'
import { explainError } from '../lib/supabase'
const auth = useAuthStore()
const mode = ref('login')
const email = ref('')
const password = ref('')
const pending = ref(false)
const message = ref('')
const error = ref('')
async function submit() {
  error.value = ''; message.value = ''; pending.value = true
  try {
    if (mode.value === 'login') await auth.signIn(email.value.trim(), password.value)
    else {
      const data = await auth.signUp(email.value.trim(), password.value)
      if (!data.session) message.value = '注册成功！请检查验证邮件。若在后台关闭了邮件验证，可直接登录。'
      else message.value = '注册并登录成功。'
    }
  } catch(e) { error.value = explainError(e) } finally { pending.value = false }
}
</script>
<template>
  <div class="min-h-screen bg-[#fafafa] grid place-items-center p-5"><div class="w-full max-w-[410px]">
    <div class="mb-10 flex items-center justify-center gap-2"><div class="bg-zinc-900 text-white p-2 rounded-xl"><BookOpen :size="25" /></div><span class="text-2xl font-bold tracking-tight">NoteSpace</span></div>
    <div class="rounded-2xl bg-white border border-zinc-200 shadow-sm px-8 py-9"><h1 class="text-2xl font-semibold text-center">{{ mode==='login' ? '欢迎回来' : '创建账号' }}</h1><p class="text-zinc-500 text-center text-sm mt-2 mb-8">你的知识空间，从这里开始</p>
      <form @submit.prevent="submit" class="space-y-4"><label class="block text-sm font-medium">邮箱<input v-model="email" required type="email" autocomplete="email" placeholder="name@example.com" class="mt-2 w-full border border-zinc-200 rounded-lg px-3 py-2.5 focus:ring-2 focus:ring-blue-100 focus:border-blue-400" /></label>
        <label class="block text-sm font-medium">密码<input v-model="password" required type="password" minlength="6" :autocomplete="mode==='login'?'current-password':'new-password'" placeholder="至少 6 位" class="mt-2 w-full border border-zinc-200 rounded-lg px-3 py-2.5 focus:ring-2 focus:ring-blue-100 focus:border-blue-400" /></label>
        <p v-if="error" role="alert" class="text-red-600 text-sm">{{error}}</p><p v-if="message" class="text-green-700 text-sm">{{message}}</p>
        <button :disabled="pending" class="w-full flex items-center justify-center gap-2 bg-zinc-900 text-white rounded-lg py-3 font-medium hover:bg-zinc-700">{{pending?'处理中…':mode==='login'?'登录':'注册'}}<ArrowRight :size="17" /></button>
      </form>
      <p class="text-center text-sm text-zinc-500 mt-6">{{mode==='login'?'还没有账号？':'已有账号？'}} <button class="text-blue-600 hover:underline font-medium" @click="mode=mode==='login'?'signup':'login';error='';message=''">{{mode==='login'?'立即注册':'返回登录'}}</button></p>
    </div><p class="text-center text-xs text-zinc-400 mt-5">Vue 3 · Supabase · Tailwind CSS</p>
  </div></div>
</template>
