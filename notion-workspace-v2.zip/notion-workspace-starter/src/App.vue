<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useAuthStore } from './stores/auth'
import { useWorkspaceStore } from './stores/workspace'
import { configured } from './lib/supabase'
import LoginView from './views/LoginView.vue'
import WorkspaceView from './views/WorkspaceView.vue'
const auth = useAuthStore()
const workspace = useWorkspaceStore()
const loadError = ref('')
const loadedFor = ref('')
const ready = computed(() => !auth.loading && (auth.user ? loadedFor.value === auth.user.id : true))
onMounted(() => auth.init())
function reloadPage(){ window.location.reload() }
watch(() => auth.user?.id, async id => {
  if (!id) { workspace.reset(); loadedFor.value = ''; loadError.value = ''; return }
  loadedFor.value = ''
  try { await workspace.loadWorkspaces(); loadedFor.value = id } catch(e) { loadError.value = e.message; loadedFor.value = id }
}, { immediate: true })
</script>
<template>
  <div v-if="!configured" class="min-h-screen flex items-center justify-center bg-zinc-50 p-6"><div class="max-w-xl bg-white border rounded-xl p-8 shadow-sm"><h1 class="text-xl font-semibold mb-3">需要配置 Supabase</h1><p class="text-zinc-600 leading-7">复制 <code>.env.example</code> 为 <code>.env</code>，填写 Supabase URL 和 Publishable/anon Key，先在 SQL Editor 执行 <code>supabase/schema.sql</code>，随后重启开发服务器。</p></div></div>
  <div v-else-if="!ready" class="h-screen flex items-center justify-center text-zinc-500">正在加载知识空间…</div>
  <LoginView v-else-if="!auth.user" />
  <div v-else-if="loadError" class="p-8"><p class="mb-4 text-red-600">加载失败：{{ loadError }}</p><button class="rounded border px-4 py-2" @click="reloadPage()">刷新重试</button></div>
  <WorkspaceView v-else />
</template>
