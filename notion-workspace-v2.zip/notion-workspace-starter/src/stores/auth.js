import { defineStore } from 'pinia'
import { ref } from 'vue'
import { supabase } from '../lib/supabase'
export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const loading = ref(true)
  let subscription = null
  async function init() {
    if (!supabase) { loading.value = false; return }
    const { data: { session }, error } = await supabase.auth.getSession()
    if (error) console.warn(error)
    user.value = session?.user ?? null
    if (!subscription) {
      const { data } = supabase.auth.onAuthStateChange((_event, session) => { user.value = session?.user ?? null })
      subscription = data.subscription
    }
    loading.value = false
  }
  async function signIn(email, password) { const { error } = await supabase.auth.signInWithPassword({ email, password }); if (error) throw error }
  async function signUp(email, password) { const { data, error } = await supabase.auth.signUp({ email, password }); if (error) throw error; return data }
  async function signOut() { const { error } = await supabase.auth.signOut(); if (error) throw error }
  return { user, loading, init, signIn, signUp, signOut }
})
