import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { supabase } from '../lib/supabase'
export const useWorkspaceStore = defineStore('workspace', () => {
  const workspaces = ref([])
  const currentId = ref(localStorage.getItem('ns.workspace') || '')
  const pages = ref([])
  const trash = ref([])
  const members = ref([])
  const busy = ref(false)
  const error = ref('')
  const current = computed(() => workspaces.value.find(w => w.id === currentId.value) ?? null)
  const pageMap = computed(() => new Map(pages.value.map(p => [p.id, p])))
  const tree = computed(() => {
    const nodes = new Map(pages.value.map(p => [p.id, { ...p, children: [] }]))
    const roots = []
    for (const node of nodes.values()) {
      const parent = nodes.get(node.parent_id)
      if (parent && parent.id !== node.id) parent.children.push(node)
      else roots.push(node)
    }
    const order = items => { items.sort((a, b) => a.sort_order - b.sort_order || a.created_at.localeCompare(b.created_at)); items.forEach(n => order(n.children)) }
    order(roots)
    return roots
  })
  async function loadWorkspaces() {
    const { data, error: e } = await supabase.from('workspaces').select('id,name,owner_id,created_at').order('created_at')
    if (e) throw e
    workspaces.value = data ?? []
    if (!workspaces.value.some(w => w.id === currentId.value)) currentId.value = workspaces.value[0]?.id || ''
    localStorage.setItem('ns.workspace', currentId.value)
    if (currentId.value) await loadPages()
    else pages.value = []
  }
  async function chooseWorkspace(id) {
    if (currentId.value === id) return
    currentId.value = id
    localStorage.setItem('ns.workspace', id)
    pages.value = []
    await loadPages()
  }
  async function loadPages() {
    if (!currentId.value) { pages.value = []; return }
    const target = currentId.value
    const { data, error: e } = await supabase.from('pages').select('id,workspace_id,parent_id,title,icon,sort_order,created_at,updated_at').eq('workspace_id', target).is('deleted_at',null).order('sort_order')
    if (e) throw e
    if (target === currentId.value) pages.value = data ?? []
  }
  async function createWorkspace(name) {
    const { data, error: e } = await supabase.from('workspaces').insert({ name: name.trim() }).select('id,name,owner_id,created_at').single()
    if (e) throw e
    workspaces.value.push(data)
    await chooseWorkspace(data.id)
    return data
  }
  async function renameWorkspace(id, name) {
    const { error: e } = await supabase.from('workspaces').update({ name: name.trim() }).eq('id', id)
    if (e) throw e
    const found = workspaces.value.find(w => w.id === id)
    if (found) found.name = name.trim()
  }
  async function createPage(parentId = null, title = '无标题') {
    const { data, error: e } = await supabase.rpc('create_page', { p_workspace_id: currentId.value, p_parent_id: parentId, p_title: title })
    if (e) throw e
    await loadPages()
    return data
  }
  async function updatePage(id, patch) {
    const { data, error: e } = await supabase.from('pages').update(patch).eq('id', id).select('id,workspace_id,parent_id,title,icon,sort_order,created_at,updated_at').single()
    if (e) throw e
    pages.value = pages.value.map(p => p.id === id ? data : p)
    return data
  }
  async function deletePage(id) {
    const { error: e } = await supabase.rpc('trash_page', { p_page_id: id })
    if (e) throw e
    await loadPages()
    await loadTrash()
  }
  async function loadTrash() {
    if (!currentId.value) { trash.value = []; return }
    const { data, error: e } = await supabase.from('pages').select('id,title,icon,deleted_at,parent_id').eq('workspace_id',currentId.value).not('deleted_at','is',null).order('deleted_at',{ascending:false})
    if (e) throw e
    trash.value = data ?? []
  }
  async function restorePage(id) {
    const { error: e } = await supabase.rpc('restore_page',{p_page_id:id})
    if (e) throw e
    await Promise.all([loadPages(),loadTrash()])
  }
  async function purgePage(id) {
    const { error: e } = await supabase.rpc('purge_page',{p_page_id:id})
    if (e) throw e
    await loadTrash()
  }
  async function loadMembers() {
    if (!currentId.value) {members.value=[];return}
    const {data,error:e}=await supabase.from('workspace_members').select('user_id,role').eq('workspace_id',currentId.value)
    if(e)throw e
    members.value=data??[]
  }
  async function invite(email,role='editor') {
    const {error:e}=await supabase.rpc('create_workspace_invite',{p_workspace_id:currentId.value,p_email:email.trim(),p_role:role})
    if(e)throw e
  }
  async function acceptInvites() {
    const {error:e}=await supabase.rpc('accept_my_invites')
    if(e)throw e
    await loadWorkspaces()
  }
  async function loadInvites() {
    const {data,error:e}=await supabase.from('workspace_invitations').select('id,email,role,status,created_at').eq('workspace_id',currentId.value).order('created_at',{ascending:false})
    if(e)throw e
    return data??[]
  }
  async function movePage(id, targetId, placement) {
    const { error: e } = await supabase.rpc('move_page', { p_page_id: id, p_target_page_id: targetId, p_placement: placement })
    if (e) throw e
    await loadPages()
  }
  function reset() { workspaces.value = []; currentId.value = ''; pages.value = []; trash.value = []; members.value = []; localStorage.removeItem('ns.workspace') }
  return { workspaces, currentId, current, pages, pageMap, tree, busy, error, loadWorkspaces, chooseWorkspace, loadPages, createWorkspace, renameWorkspace, createPage, updatePage, deletePage, movePage, loadTrash, restorePage, purgePage, trash, members, loadMembers, invite, acceptInvites, loadInvites, reset }
})
