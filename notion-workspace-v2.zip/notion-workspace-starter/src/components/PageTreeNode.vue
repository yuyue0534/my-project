<script setup>
import { computed, ref } from 'vue'
import { ChevronRight, ChevronDown, FileText, Plus, Ellipsis } from 'lucide-vue-next'
const props = defineProps({ node: { type: Object, required: true }, depth: { type: Number, default: 0 }, activeId: String, expanded: Object, canEdit: Boolean, draggingId: String })
const emit = defineEmits(['select','toggle','add','rename','remove','move','dragging'])
const showMenu = ref(false)
const hoveredPlacement = ref('')
const open = computed(() => props.expanded[props.node.id] !== false)
function toggle(){ emit('toggle', props.node.id) }
function dragStart(e) {
  if (!props.canEdit) return e.preventDefault()
  e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', props.node.id)
  emit('dragging', props.node.id)
}
function dragOver(e) {
  if (!props.canEdit || !props.draggingId || props.draggingId === props.node.id) return
  e.preventDefault()
  const rect = e.currentTarget.getBoundingClientRect()
  const fraction = (e.clientY - rect.top) / rect.height
  hoveredPlacement.value = fraction < .26 ? 'before' : fraction > .74 ? 'after' : 'inside'
  e.dataTransfer.dropEffect = 'move'
}
function drop(e) {
  e.preventDefault(); e.stopPropagation()
  const id = e.dataTransfer.getData('text/plain') || props.draggingId
  if (id && id !== props.node.id && hoveredPlacement.value) emit('move', id, props.node.id, hoveredPlacement.value)
  hoveredPlacement.value = ''; emit('dragging', '')
}
function clearDrag(){ hoveredPlacement.value = '' }
</script>
<template>
  <div>
    <div class="tree-row group relative flex items-center rounded-md mr-2 text-[13px] select-none hover:bg-zinc-200/70 h-[31px] text-zinc-600" :class="[activeId===node.id?'bg-zinc-200/90 text-zinc-900 font-medium':'',hoveredPlacement?'drag-'+hoveredPlacement:'']" :style="{paddingLeft: (depth*15+8)+'px'}" :draggable="canEdit" @dragstart="dragStart" @dragend="emit('dragging','')" @dragover="dragOver" @dragleave="clearDrag" @drop="drop">
      <button class="w-5 h-6 shrink-0 grid place-items-center hover:bg-zinc-300 rounded" @click.stop="toggle"><component :is="open?ChevronDown:ChevronRight" :size="13"/></button>
      <button class="flex items-center gap-2 min-w-0 flex-1 text-left" @click="emit('select',node.id)"><span class="text-base leading-none">{{node.icon || '📄'}}</span><span class="truncate">{{node.title || '无标题'}}</span></button>
      <div v-if="canEdit" class="node-action flex items-center gap-0.5 mr-1 shrink-0"><button title="添加子页面" class="p-1 rounded hover:bg-zinc-300" @click.stop="emit('add',node.id)"><Plus :size="14"/></button><div class="relative"><button title="更多选项" class="p-1 rounded hover:bg-zinc-300" @click.stop="showMenu=!showMenu"><Ellipsis :size="15"/></button><div v-if="showMenu" class="absolute right-0 top-7 z-30 w-32 bg-white shadow-xl border rounded-lg p-1 text-zinc-800"><button class="block w-full text-left rounded px-3 py-2 hover:bg-zinc-100" @click.stop="emit('rename',node.id);showMenu=false">重命名</button><button class="block w-full text-left rounded px-3 py-2 text-red-600 hover:bg-red-50" @click.stop="emit('remove',node.id);showMenu=false">删除页面</button></div></div></div>
    </div>
    <div v-if="open"><PageTreeNode v-for="child in node.children" :key="child.id" :node="child" :depth="depth+1" :active-id="activeId" :expanded="expanded" :can-edit="canEdit" :dragging-id="draggingId" @select="(...args)=>emit('select',...args)" @toggle="(...args)=>emit('toggle',...args)" @add="(...args)=>emit('add',...args)" @rename="(...args)=>emit('rename',...args)" @remove="(...args)=>emit('remove',...args)" @move="(...args)=>emit('move',...args)" @dragging="(...args)=>emit('dragging',...args)" /></div>
  </div>
</template>
