<script setup>
import { ref, watch, onBeforeUnmount, computed } from 'vue'
import { useEditor, EditorContent } from '@tiptap/vue-3'
import StarterKit from '@tiptap/starter-kit'
import Placeholder from '@tiptap/extension-placeholder'
import Underline from '@tiptap/extension-underline'
import Link from '@tiptap/extension-link'
import Image from '@tiptap/extension-image'
import { supabase, explainError } from '../lib/supabase'
import { Bold, Italic, Underline as UnderlineIcon, Heading1, Heading2, List, ListOrdered, Quote, Code2, Link2, ImagePlus, Undo2, Redo2, Save } from 'lucide-vue-next'
const props=defineProps({pageId:{type:String,required:true},canEdit:Boolean})
const status=ref('加载中…'), error=ref(''), dirty=ref(false), version=ref(0), remoteChanged=ref(false)
let timer=null, seq=0, disposed=false, lastCommitted=''
const editor=useEditor({
  extensions:[StarterKit,Underline,Link.configure({openOnClick:false}),Image,Placeholder.configure({placeholder:'输入内容，或键入 / 查看快捷命令…'})],
  content:{type:'doc',content:[{type:'paragraph'}]},
  editable:props.canEdit,
  editorProps:{attributes:{class:'notespace-editor min-h-[320px] outline-none'}},
  onUpdate:()=>{
    if (applying) return
    dirty.value=true;status.value='待保存';error.value='';schedule()
  }
})
let applying=false
function schedule(){clearTimeout(timer);timer=setTimeout(()=>save(),850)}
function setDocument(content){
  if(!editor.value)return
  applying=true
  editor.value.commands.setContent(content || {type:'doc',content:[{type:'paragraph'}]},false)
  applying=false
}
async function load(){
  const ticket=++seq;clearTimeout(timer);dirty.value=false;remoteChanged.value=false;status.value='加载中…'
  const {data,error:e}=await supabase.from('pages').select('id,content,content_version').eq('id',props.pageId).is('deleted_at',null).single()
  if(ticket!==seq||disposed)return
  if(e){status.value='加载失败';error.value=explainError(e);return}
  setDocument(data.content);version.value=data.content_version;lastCommitted=JSON.stringify(data.content);status.value='已保存'
}
async function save(){
  clearTimeout(timer)
  if(!dirty.value||!props.canEdit||!editor.value)return
  const ticket=seq,id=props.pageId,base=version.value,content=editor.value.getJSON(),serialized=JSON.stringify(content)
  status.value='保存中…'
  const {data,error:e}=await supabase.rpc('save_page_content',{p_page_id:id,p_content:content,p_expected_version:base})
  if(ticket!==seq||disposed)return
  if(e){status.value='保存失败';error.value= /content_conflict/i.test(e.message)?'其他设备已修改此页面。请复制当前内容保存到别处，再点击「加载远端」以避免覆盖。':explainError(e);remoteChanged.value=/content_conflict/i.test(e.message);return}
  version.value=data;lastCommitted=serialized
  if(JSON.stringify(editor.value.getJSON())===serialized){dirty.value=false;status.value='已保存'}
  else {dirty.value=true;status.value='待保存';schedule()}
}
function refreshRemote(){if(dirty.value&&!confirm('当前本地内容尚未保存，确定放弃并加载远端版本吗？'))return;load()}
function insertImage(){const url=prompt('图片 URL（https://）');if(url&&/^https:\/\//i.test(url))editor.value?.chain().focus().setImage({src:url}).run()}
function insertLink(){const url=prompt('链接 URL（https://）');if(url&&/^https:\/\//i.test(url))editor.value?.chain().focus().setLink({href:url}).run()}
const actions=computed(()=>[
  {name:'加粗',icon:Bold,fn:()=>editor.value?.chain().focus().toggleBold().run()},
  {name:'斜体',icon:Italic,fn:()=>editor.value?.chain().focus().toggleItalic().run()},
  {name:'下划线',icon:UnderlineIcon,fn:()=>editor.value?.chain().focus().toggleUnderline().run()},
  {name:'一级标题',icon:Heading1,fn:()=>editor.value?.chain().focus().toggleHeading({level:1}).run()},
  {name:'二级标题',icon:Heading2,fn:()=>editor.value?.chain().focus().toggleHeading({level:2}).run()},
  {name:'无序列表',icon:List,fn:()=>editor.value?.chain().focus().toggleBulletList().run()},
  {name:'有序列表',icon:ListOrdered,fn:()=>editor.value?.chain().focus().toggleOrderedList().run()},
  {name:'引用',icon:Quote,fn:()=>editor.value?.chain().focus().toggleBlockquote().run()},
  {name:'代码块',icon:Code2,fn:()=>editor.value?.chain().focus().toggleCodeBlock().run()},
  {name:'链接',icon:Link2,fn:insertLink},
  {name:'图片',icon:ImagePlus,fn:insertImage},
  {name:'撤销',icon:Undo2,fn:()=>editor.value?.chain().focus().undo().run()},
  {name:'重做',icon:Redo2,fn:()=>editor.value?.chain().focus().redo().run()}
])
const slash=ref(false)
function onKeydown(e){if(e.key==='/'&&!e.ctrlKey&&!e.metaKey){slash.value=true};if(e.key==='Escape')slash.value=false}
function doAction(a){a.fn();slash.value=false}
watch(()=>props.pageId,load,{immediate:true})
watch(()=>props.canEdit,v=>editor.value?.setEditable(v))
const channel=supabase.channel('content-'+props.pageId)
function remoteUpdate(payload){
  if(payload.new?.id!==props.pageId)return
  if(payload.new.content_version===version.value)return
  if(dirty.value){remoteChanged.value=true;status.value='发现远端更改';return}
  load()
}
channel.on('postgres_changes',{event:'UPDATE',schema:'public',table:'pages',filter:`id=eq.${props.pageId}`},remoteUpdate).subscribe()
onBeforeUnmount(()=>{if(dirty.value && !remoteChanged.value)save();disposed=true;seq++;clearTimeout(timer);supabase.removeChannel(channel)})
</script>
<template>
<div class="mt-9" @keydown="onKeydown">
  <div class="sticky top-0 z-20 bg-white/95 backdrop-blur border-y py-2 flex gap-1 items-center flex-wrap">
    <button v-for="a in actions" :key="a.name" type="button" :disabled="!canEdit" :title="a.name" class="p-1.5 rounded hover:bg-zinc-100 text-zinc-600" @click="doAction(a)"><component :is="a.icon" :size="16"/></button>
    <span class="flex-1"/><button :disabled="!dirty || !canEdit" class="flex items-center gap-1 text-xs text-zinc-500 p-1.5 hover:bg-zinc-100 rounded" @click="save"><Save :size="14"/>{{status}}</button>
  </div>
  <p v-if="error" class="text-red-600 text-xs mt-3" role="alert">{{error}}</p>
  <div v-if="remoteChanged" class="bg-amber-50 rounded-lg p-3 text-xs text-amber-800 mt-3">远端已有新版本，请先复制或备份本地内容。<button class="underline ml-2" @click="refreshRemote">加载远端</button></div>
  <div v-if="slash && canEdit" class="mt-2 border rounded-xl shadow-sm p-2 bg-white flex flex-wrap gap-1"><span class="text-xs text-zinc-400 p-2">快捷插入：</span><button v-for="a in actions.slice(3,12)" :key="a.name" class="text-xs p-2 hover:bg-zinc-100 rounded" @click="doAction(a)">{{a.name}}</button><button class="text-xs text-zinc-400" @click="slash=false">关闭</button></div>
  <EditorContent :editor="editor" class="mt-7"/>
  <p class="text-xs text-zinc-400 mt-8">支持 Markdown 输入快捷方式（例如 # 标题、- 列表）、自动保存、撤销重做。{{canEdit?'':'当前为只读模式。'}}</p>
</div>
</template>
