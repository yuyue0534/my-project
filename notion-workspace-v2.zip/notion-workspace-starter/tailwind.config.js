export default {
  content: ['./index.html', './src/**/*.{vue,js}'],
  theme: { extend: { colors: { accent: '#2f6feb' }, fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'] } } },
  plugins: [],
}
