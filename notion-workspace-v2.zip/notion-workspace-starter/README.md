# NoteSpace v2 — Vue 3 + Supabase + Tailwind CSS

基于 v1 项目的可运行源码（JavaScript，非 TypeScript）。包含 Workspace、侧边栏、无限级页面树及拖拽、Tiptap JSON Block 编辑、乐观锁自动保存、跨标签/设备 Realtime 更新、软删除回收站、邮箱成员邀请（站内接受）。

## 安装（Windows 11 / macOS / Linux）

要求 Node.js 20.19+ 或 22.12+，npm，Supabase 项目。

```bash
npm install
copy .env.example .env
npm run dev
```

在 Windows PowerShell 可使用 `Copy-Item .env.example .env`，macOS/Linux 使用 `cp .env.example .env`。

填写 `.env`：

```env
VITE_SUPABASE_URL=https://你的项目.supabase.co
VITE_SUPABASE_ANON_KEY=你的 publishable/anon key
```

不要使用 `service_role` 密钥。

**新建 Supabase 项目**：先在 Supabase SQL Editor 执行 `supabase/schema.sql`，再执行 `supabase/upgrade_v2.sql`。

**已有 v1 项目**：保留现有数据库，只运行 `supabase/upgrade_v2.sql`；现有页面不会被清空。确认客户端改用新版源码。

启动：`npm run dev`。生产构建：`npm run build`。构建后 `npm run preview`。

## 功能与限制

- 页面标题、层级、拖拽排序沿用 v1。编辑器支持段落、标题、列表、粗体、斜体、下划线、引用、代码块、链接、图片 URL、撤销重做、Markdown 输入规则。
- Tiptap JSON 存入 `pages.content`；`content_version` 充当乐观锁。编辑后约 850ms 自动保存，也可手动保存；存在远程冲突时**不覆盖**本地修改。
- `pages` 的 UPDATE 通过 Supabase Realtime 触发其他已打开客户端重新读取。**不是 Yjs 字符级协作**，多人同时编辑可能触发冲突，需要人工复制/备份本地内容后再重载。
- 软删除与恢复适用于整个子页面树。永久删除无法恢复，建议先做数据库备份。
- 工作区 Owner 可填写邮箱邀请 Editor / Viewer。系统**不自动发邮件**，需要邀请者把应用访问地址发给对方；被邀请者用对应邮箱登录、完成邮箱验证，再进入任意工作区的「成员与邀请」点击接受邀请。若尚无工作区，请先创建临时工作区以看到该入口。此功能不是 Supabase Auth 的管理员创建账号流程。
- Supabase 控制台的 Database -> Publications / Realtime 检查 `pages` 已纳入 `supabase_realtime`；若需要显示其他客户端变化，应保持 Realtime 可用。
- 图片目前支持插入 HTTPS 图片 URL，不包含文件上传；没有评论、Yjs 光标同步、细粒度页面权限、邮件发送服务、定时清空回收站。
- 该工程尚未对接实际 Supabase 进行端到端联调；生产使用前应做真实账号/RLS/恢复/并发测试。

## 项目目录

```
src/
  components/BlockEditor.vue       # Tiptap 编辑器
  components/PageTreeNode.vue      # 递归页面树/拖拽
  views/WorkspaceView.vue          # 主界面+回收站+成员
  views/LoginView.vue              # 登录/注册
  stores/workspace.js              # Workspace CRUD 和拓展操作
  stores/auth.js                   # 认证
  lib/supabase.js                  # Supabase 客户端
  App.vue main.js style.css
supabase/schema.sql                # v1 初始化
supabase/upgrade_v2.sql            # v2 增量升级
```

## 操作验收建议

1. 注册并登录，创建工作区与多级页面，拖动节点调整顺序。
2. 编辑内容并观察「已保存」，刷新验证正文仍在。
3. 两个浏览器分别登录同一个账号打开同一页面，在 A 保存后检查 B 是否刷新；同时编辑时检查冲突警告与不覆盖。
4. 删除包含子页面的父节点，进入回收站恢复，并检查子页面仍在。
5. Owner 创建邮箱邀请，被邀请者使用对应**已验证邮箱**注册、登录、接受邀请；确认其 Viewer 无法编辑，Editor 可以编辑。

## 安全提示

`workspace_members` 的授权由数据库 RLS 实现。邮箱邀请由数据库 SECURITY DEFINER 函数校验 Owner 和已验证邮箱，客户端不会持有服务端密钥。请不要删除或关闭 RLS；数据库安全需要结合真实账号测试。
